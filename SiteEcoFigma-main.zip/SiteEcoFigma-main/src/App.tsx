import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { ProductLines } from "./components/ProductLines";
import { Advantages } from "./components/Advantages";
import { AdvantagesAnimation } from "./components/AdvantagesAnimation";
import { CarbonCalculator } from "./components/CarbonCalculator";
import { Applications } from "./components/Applications";
import { TrustedClients } from "./components/TrustedClients";
import { Blog } from "./components/Blog";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <ProductLines />
        <AdvantagesAnimation />
        <CarbonCalculator />
        <Advantages />
        <Applications />
        <TrustedClients />
        <Blog />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}