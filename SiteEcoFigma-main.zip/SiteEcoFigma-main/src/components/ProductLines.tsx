import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Factory, Home, Droplets, Recycle, TreePine, Waves, Zap, CheckCircle } from "lucide-react";
import ecoFloorImage from "figma:asset/813f2545190e05e0cc7b7bdd06b44c25b18987ae.png";
import ecoWoodImage from "figma:asset/6fc706283156b6b7e02f7d794eae09e05fb55ad5.png";
import ecoSeaImage from "figma:asset/81cbb1d9edb83282e1668374ec9c66da7ce7edea.png";

export function ProductLines() {
  const scrollToContact = () => {
    const element = document.getElementById("contato");
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  const products = [
    {
      id: "eco-floor",
      name: "Eco Floor",
      tagline: "Para Pisos Industriais e de Alto Tráfego",
      icon: Factory,
      description: "Solução definitiva para pisos industriais, comerciais e garagens. Cria uma superfície monolítica (sem juntas), totalmente impermeável e com resistência extrema à abrasão de máquinas, equipamentos e ataques químicos. Garante um piso seguro, de fácil higienização, que atende às normas sanitárias e não interrompe sua produção.",
      applications: [
        "Indústrias (Alimentícia, Farmacêutica)",
        "Centros Logísticos",
        "Hospitais e Laboratórios",
        "Estacionamentos e Garagens",
        "Concessionárias"
      ],
      features: [
        "Resistência extrema à abrasão e tráfego pesado",
        "Superfície monolítica (zero juntas)",
        "Cura rápida (liberação em poucas horas)",
        "Alta resistência química",
        "Fácil de limpar e atende normas sanitárias",
        "Atóxico e sem cheiro na aplicação"
      ],
      image: ecoFloorImage
    },
    {
      id: "eco-deck",
      name: "Eco Deck",
      tagline: "Para Lajes, Coberturas e Áreas Externas",
      icon: Home,
      description: "A blindagem definitiva contra infiltrações em lajes e coberturas. Forma uma membrana única, elástica e totalmente aderida à superfície, sem emendas ou pontos frágeis. Acompanha as movimentações térmicas da estrutura (dilatação e contração) e garante estanqueidade absoluta, mesmo sob sol e chuva constantes.",
      applications: [
        "Lajes de Cobertura",
        "Terraços e Varandas",
        "Jardineiras e Calhas",
        "Pisos de Áreas Externas",
        "Marquises"
      ],
      features: [
        "100% Estanque (Zero infiltração)",
        "Flexibilidade Permanente (Absorve movimentações)",
        "Resistente a Raios UV e intempéries",
        "Aplicação a frio (Dispensa quebra-quebra)",
        "Permite tráfego de pessoas",
        "Leve (não sobrecarrega a estrutura)"
      ],
      image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb29mJTIwdGVycmFjZSUyMHdhdGVycHJvb2Zpbmd8ZW58MXx8fHwxNzU4NTM4MjQ1fDA&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      id: "eco-hydrosafe",
      name: "Eco HydroSafe",
      tagline: "Para Reservatórios e Contato com Água Potável",
      icon: Droplets,
      description: "Segurança absoluta para água potável. Desenvolvido especificamente para impermeabilizar reservatórios, tanques e caixas d'água com a garantia de máxima pureza. Sua fórmula atóxica, livre de solventes e com Laudo de Potabilidade (NBR 12170), assegura que a água permaneça 100% pura e livre de qualquer contaminação.",
      applications: [
        "Reservatórios de Água Potável",
        "Caixas d'Água (concreto ou fibrocimento)",
        "Tanques de Piscicultura",
        "Indústria de Alimentos e Bebidas",
        "ETAs (Estações de Tratamento de Água)"
      ],
      features: [
        "Possui Laudo de Potabilidade (NBR 12170)",
        "Atóxico e Sem Cheiro",
        "Barreira Antimicrobiana (Impede fungos e bactérias)",
        "Resistente a produtos químicos de tratamento (cloro)",
        "Alta aderência ao concreto",
        "Pode ser aplicado em tanques de piscicultura"
      ],
      image: "https://images.unsplash.com/photo-1541888946425-d81bb19240f5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXRlciUyMHRhbmslMjByZXNlcnZvaXJ8ZW58MXx8fHwxNzU4NTM4MjQ1fDA&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      id: "eco-station",
      name: "Eco Station",
      tagline: "Para Saneamento e Ambientes Químicos Severos",
      icon: Recycle,
      description: "Proteção implacável projetada para os ambientes mais extremos. Formulado especificamente para resistir aos mais severos ataques químicos, gases corrosivos (H₂S) e abrasão constante presentes em Estações de Tratamento de Água e Esgoto (ETAs/ETEs) e indústrias químicas.",
      applications: [
        "ETEs (Estações de Tratamento de Esgoto)",
        "ETAs (Estações de Tratamento de Água)",
        "Tanques de Contenção Industrial",
        "Canaletas de Efluentes",
        "Digestores Anaeróbicos"
      ],
      features: [
        "Resistência Química Superior (Ácidos, bases, solventes)",
        "Proteção contra gases corrosivos",
        "Alta resistência à abrasão de sólidos",
        "Estanqueidade total sob pressão",
        "Aumento da vida útil do concreto",
        "Segurança operacional"
      ],
      image: "https://images.unsplash.com/photo-1581094271901-8022df4466f9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXRlciUyMHRyZWF0bWVudCUyMHBsYW50fGVufDF8fHx8MTc1ODUzODI0NXww&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      id: "eco-wood",
      name: "Eco Wood",
      tagline: "Para Madeira",
      icon: TreePine,
      description: "Conserva e impermeabiliza todos os tipos de madeira, protegendo contra umidade, mofo e a ação do tempo.",
      applications: [
        "Estruturas de madeira externa",
        "Decks e pergolados",
        "Móveis de jardim",
        "Estruturas internas",
        "Artesanato em madeira"
      ],
      features: [
        "Proteção contra umidade",
        "Anti-mofo e fungos",
        "Preserva textura natural",
        "Resistente a intempéries"
      ],
      image: ecoWoodImage
    },
    {
      id: "eco-sea",
      name: "Eco Sea",
      tagline: "Para Ambientes Marinhos",
      icon: Waves,
      description: "Projetada para suportar as condições mais severas, oferece uma impermeabilização perfeita para embarcações, docas e estruturas submersas ou em zonas de respingo garantindo uma aplicação ideal para ambientes marinhos.",
      applications: [
        "Embarcações e barcos",
        "Docas e píeres",
        "Estruturas submersas",
        "Zonas de respingo",
        "Cascos de navios"
      ],
      features: [
        "Resistente à água salgada",
        "Suporta condições extremas",
        "Proteção submersa",
        "Anti-corrosão marinha"
      ],
      image: ecoSeaImage
    },
    {
      id: "eco-steel",
      name: "Eco Steel",
      tagline: "Para Superfícies Metálicas",
      icon: Zap,
      description: "Proteção definitiva contra corrosão, ferrugem, ataques químicos e umidade em todos os tipos de superfícies metálicas.",
      applications: [
        "Estruturas metálicas",
        "Telhados metálicos",
        "Tanques e silos",
        "Equipamentos industriais",
        "Calhas e rufos"
      ],
      features: [
        "Anti-corrosão definitiva",
        "Proteção contra ferrugem",
        "Resistente a ataques químicos",
        "Barreira contra umidade"
      ],
      image: "https://images.unsplash.com/photo-1741446458387-74132b7d49cc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwYnVpbGRpbmclMjByb29mJTIwY29hdGluZ3xlbnwxfHx8fDE3NTg1MzgyNDV8MA&ixlib=rb-4.1.0&q=80&w=1080"
    }
  ];

  return (
    <section id="produtos" className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-[#3eada2]/10 text-[#2d9186] hover:bg-[#3eada2]/20 border border-[#3eada2]/30">
            Linhas Especializadas
          </Badge>
          <h2 className="text-3xl lg:text-4xl mb-4 text-gray-900">
            Soluções Específicas para Cada Necessidade
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Cada linha EcoConstruction foi desenvolvida para atender demandas específicas, 
            mantendo sempre a qualidade, sustentabilidade e eficiência.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {products.map((product) => {
            const IconComponent = product.icon;
            return (
              <Card key={product.id} className="overflow-hidden hover:shadow-2xl transition-all duration-300 border-2 border-gray-100 hover:border-[#3eada2]/30">
                <div className="relative h-64">
                  <img
                    src={product.image}
                    alt={`Produto ${product.name}`}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent"></div>
                  <div className="absolute top-4 left-4">
                    <div className="bg-[#3eada2]/95 backdrop-blur-sm p-3 rounded-xl shadow-lg">
                      <IconComponent className="h-6 w-6 text-white" />
                    </div>
                  </div>
                  <div className="absolute bottom-4 right-4">
                    <Badge className="bg-[#3eada2] text-white border-white/20 shadow-lg">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Disponível
                    </Badge>
                  </div>
                </div>
                
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-2xl text-gray-900">{product.name}</CardTitle>
                      <CardDescription className="text-[#2d9186] mt-1">{product.tagline}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-6">
                  <p className="text-gray-600 leading-relaxed">{product.description}</p>
                  
                  <div>
                    <h4 className="text-gray-900 mb-3 flex items-center">
                      <div className="h-1 w-8 bg-[#3eada2] rounded mr-2"></div>
                      Principais Características
                    </h4>
                    <div className="grid grid-cols-1 gap-2">
                      {product.features.map((feature, idx) => (
                        <div key={idx} className="flex items-start space-x-2">
                          <div className="w-1.5 h-1.5 bg-[#3eada2] rounded-full mt-2 flex-shrink-0"></div>
                          <span className="text-sm text-gray-600">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-gray-900 mb-3 flex items-center">
                      <div className="h-1 w-8 bg-[#3eada2] rounded mr-2"></div>
                      Aplicações Recomendadas
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {product.applications.slice(0, 3).map((app, idx) => (
                        <Badge key={idx} variant="secondary" className="bg-gray-100 text-gray-700 hover:bg-gray-200">
                          {app}
                        </Badge>
                      ))}
                      {product.applications.length > 3 && (
                        <Badge variant="secondary" className="bg-[#3eada2]/10 text-[#2d9186] hover:bg-[#3eada2]/20">
                          +{product.applications.length - 3} mais
                        </Badge>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex space-x-3 pt-4">
                    <Button 
                      onClick={scrollToContact}
                      className="flex-1 bg-[#3eada2] hover:bg-[#2d9186] text-white shadow-lg hover:shadow-xl transition-all duration-300"
                    >
                      Solicitar Orçamento
                    </Button>
                    <Button 
                      onClick={scrollToContact}
                      variant="outline" 
                      className="border-2 border-[#3eada2] text-[#2d9186] hover:bg-[#3eada2]/10"
                    >
                      Saiba Mais
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
