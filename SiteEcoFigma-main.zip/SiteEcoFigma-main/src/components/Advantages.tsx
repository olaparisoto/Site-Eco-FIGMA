import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { 
  Leaf, 
  DollarSign, 
  Clock, 
  Shield, 
  Users, 
  Wrench, 
  TreePine, 
  AlertTriangle,
  CheckCircle2,
  TrendingUp
} from "lucide-react";

export function Advantages() {
  const advantages = [
    {
      icon: Leaf,
      title: "100% Ecológico",
      description: "Feito com resina vegetal, totalmente sustentável e renovável",
      details: [
        "Zero emissão de vapores tóxicos",
        "Sem cheiro durante aplicação",
        "Não agride o meio ambiente",
        "Matéria-prima renovável"
      ],
      color: "text-green-600",
      bgColor: "bg-green-50"
    },
    {
      icon: DollarSign,
      title: "Melhor Custo-Benefício",
      description: "Economia comprovada a longo prazo com durabilidade superior",
      details: [
        "Economia de até 60% em mão de obra",
        "Não precisa de equipamentos caros",
        "Evita quebra-quebra desnecessário",
        "Maior durabilidade = menos retrabalho"
      ],
      color: "text-blue-600",
      bgColor: "bg-blue-50"
    },
    {
      icon: Clock,
      title: "Aplicação Rápida",
      description: "Aplicação 3x mais rápida que métodos tradicionais",
      details: [
        "Não para a obra por dias",
        "Aplicação sobre qualquer superfície",
        "Secagem rápida",
        "Menos tempo de projeto"
      ],
      color: "text-orange-600",
      bgColor: "bg-orange-50"
    },
    {
      icon: Users,
      title: "Fácil Aplicação",
      description: "Dispensa mão de obra especializada, qualquer profissional aplica",
      details: [
        "Aplicação com rodos, pincéis ou rolos",
        "Não precisa de treinamento específico",
        "Reduz custos com especialistas",
        "Aderência em qualquer superfície"
      ],
      color: "text-purple-600",
      bgColor: "bg-purple-50"
    },
    {
      icon: Shield,
      title: "Proteção Superior",
      description: "Resistência comprovada contra diversos agentes agressivos",
      details: [
        "Resistente a pressões hidrostáticas",
        "Proteção contra ataques químicos",
        "Resistente à abrasão e corrosão",
        "Proteção contra intempéries"
      ],
      color: "text-red-600",
      bgColor: "bg-red-50"
    },
    {
      icon: CheckCircle2,
      title: "Certificações",
      description: "Atende às principais normas brasileiras e internacionais",
      details: [
        "NBR 12170 - Potabilidade",
        "NBR 15487 - Poliuretano",
        "ASTM - Padrões internacionais",
        "ISO 14000 - Sustentabilidade"
      ],
      color: "text-indigo-600",
      bgColor: "bg-indigo-50"
    }
  ];

  const comparison = [
    {
      feature: "Emissão de Vapores",
      traditional: "Alta emissão tóxica",
      ecoconstruction: "Zero emissão",
      advantage: true
    },
    {
      feature: "Tempo de Aplicação",
      traditional: "5-10 dias",
      ecoconstruction: "1-3 dias",
      advantage: true
    },
    {
      feature: "Mão de Obra",
      traditional: "Especializada",
      ecoconstruction: "Qualquer profissional",
      advantage: true
    },
    {
      feature: "Durabilidade",
      traditional: "5-8 anos",
      ecoconstruction: "25+ anos",
      advantage: true
    },
    {
      feature: "Impacto Ambiental",
      traditional: "Alto (petróleo)",
      ecoconstruction: "Zero (vegetal)",
      advantage: true
    },
    {
      feature: "Custo Total (5 anos)",
      traditional: "R$ 100.000",
      ecoconstruction: "R$ 65.000",
      advantage: true
    }
  ];

  return (
    <section id="vantagens" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-green-100 text-green-800 hover:bg-green-100">
            Vantagens Competitivas
          </Badge>
          <h2 className="text-3xl lg:text-4xl mb-4 text-gray-900">
            Por que Escolher a <span className="text-green-600">EcoConstruction</span>?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Nossa solução supera os impermeabilizantes tradicionais em todos os aspectos: 
            sustentabilidade, eficiência, economia e durabilidade.
          </p>
        </div>

        {/* Main Advantages Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {advantages.map((advantage, index) => {
            const IconComponent = advantage.icon;
            return (
              <Card key={index} className="hover:shadow-lg transition-shadow border-0 bg-white">
                <CardHeader>
                  <div className={`w-12 h-12 ${advantage.bgColor} rounded-lg flex items-center justify-center mb-4`}>
                    <IconComponent className={`h-6 w-6 ${advantage.color}`} />
                  </div>
                  <CardTitle className="text-xl text-gray-900">{advantage.title}</CardTitle>
                  <p className="text-gray-600">{advantage.description}</p>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {advantage.details.map((detail, idx) => (
                      <li key={idx} className="flex items-start space-x-2">
                        <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-gray-600">{detail}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Comparison Table */}
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-green-600 to-green-700 px-8 py-6">
            <h3 className="text-2xl text-white text-center">
              EcoConstruction vs. Impermeabilizantes Tradicionais
            </h3>
            <p className="text-green-100 text-center mt-2">
              Comparação técnica e econômica detalhada
            </p>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50">
                  <th className="px-6 py-4 text-left">Característica</th>
                  <th className="px-6 py-4 text-center text-gray-600">Impermeabilizantes Tradicionais</th>
                  <th className="px-6 py-4 text-center text-green-600">EcoConstruction</th>
                  <th className="px-6 py-4 text-center">Vantagem</th>
                </tr>
              </thead>
              <tbody>
                {comparison.map((item, index) => (
                  <tr key={index} className="border-t border-gray-100 hover:bg-gray-50">
                    <td className="px-6 py-4 font-medium text-gray-900">{item.feature}</td>
                    <td className="px-6 py-4 text-center text-gray-600">{item.traditional}</td>
                    <td className="px-6 py-4 text-center text-green-600 font-medium">{item.ecoconstruction}</td>
                    <td className="px-6 py-4 text-center">
                      {item.advantage && (
                        <div className="flex justify-center">
                          <TrendingUp className="h-5 w-5 text-green-600" />
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Call to Action */}
        <div className="mt-16 text-center">
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-green-100">
            <AlertTriangle className="h-12 w-12 text-orange-500 mx-auto mb-4" />
            <h3 className="text-2xl mb-4 text-gray-900">
              Ainda Usando Impermeabilizantes à Base de Petróleo?
            </h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Está na hora de fazer a mudança para uma solução mais segura, econômica e sustentável. 
              Milhares de empresas já fizeram a transição e obtiveram resultados superiores.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Badge className="bg-red-100 text-red-800 px-4 py-2">
                Vapores Tóxicos
              </Badge>
              <Badge className="bg-red-100 text-red-800 px-4 py-2">
                Mão de Obra Cara
              </Badge>
              <Badge className="bg-red-100 text-red-800 px-4 py-2">
                Baixa Durabilidade
              </Badge>
              <Badge className="bg-red-100 text-red-800 px-4 py-2">
                Prejudica Meio Ambiente
              </Badge>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}