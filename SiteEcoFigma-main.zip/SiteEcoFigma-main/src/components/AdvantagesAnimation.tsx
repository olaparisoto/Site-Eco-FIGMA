import { useEffect, useRef, useState } from 'react';
import { motion, useScroll, useTransform, useSpring } from 'motion/react';
import { Droplets, Shield, Clock, Leaf, TrendingDown, Zap, CheckCircle2, Award, Sparkles } from 'lucide-react';

export function AdvantagesAnimation() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isInView, setIsInView] = useState(false);
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  // Smooth spring animations
  const smoothProgress = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  const opacity = useTransform(smoothProgress, [0, 0.2, 0.8, 1], [0, 1, 1, 0]);
  const scale = useTransform(smoothProgress, [0, 0.2, 0.8, 1], [0.8, 1, 1, 0.8]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsInView(entry.isIntersecting);
      },
      { threshold: 0.1 }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const advantages = [
    {
      icon: TrendingDown,
      title: 'Economia de até 40%',
      description: 'Comparado às mantas asfálticas tradicionais',
      metric: '40%',
      color: 'from-emerald-500 to-teal-600',
      details: [
        'Menor custo de material',
        'Redução de mão de obra',
        'Menos desperdício'
      ]
    },
    {
      icon: Shield,
      title: 'Durabilidade Superior',
      description: 'Proteção de longa duração sem manutenção',
      metric: 'Durável',
      color: 'from-blue-500 to-indigo-600',
      details: [
        'Resistência UV certificada',
        'Anti-corrosão',
        'Estabilidade térmica'
      ]
    },
    {
      icon: Leaf,
      title: '100% Sustentável',
      description: 'Resina vegetal atóxica e ecológica',
      metric: '0 CO₂',
      color: 'from-green-500 to-emerald-600',
      details: [
        'Matéria-prima renovável',
        'Biodegradável',
        'Carbon neutral'
      ]
    },
    {
      icon: Clock,
      title: 'Aplicação Rápida',
      description: 'Até 5x mais rápido que métodos tradicionais',
      metric: '5x',
      color: 'from-orange-500 to-amber-600',
      details: [
        'Secagem em 2 horas',
        'Aplicação a frio',
        'Mono-componente'
      ]
    },
    {
      icon: Droplets,
      title: 'Impermeabilização Total',
      description: 'Certificações NBR 9952 e ASTM D6083',
      metric: '100%',
      color: 'from-cyan-500 to-blue-600',
      details: [
        'Sem emendas',
        'Elasticidade permanente',
        'Aderência superior'
      ]
    },
    {
      icon: Zap,
      title: 'Zero Vapores Tóxicos',
      description: 'Sem cheiro, seguro para toda equipe',
      metric: '0 VOC',
      color: 'from-purple-500 to-violet-600',
      details: [
        'Atóxico certificado',
        'Sem inflamáveis',
        'Uso em áreas ocupadas'
      ]
    }
  ];

  return (
    <section id="vantagens" ref={containerRef} className="relative py-32 bg-gradient-to-b from-slate-50 via-white to-blue-50 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 left-10 w-96 h-96 bg-emerald-400/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-blue-400/10 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <motion.div
          style={{ opacity, scale }}
          className="text-center mb-20"
        >
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="inline-block mb-4"
          >
            <div className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-blue-500 text-white px-6 py-2 rounded-full">
              <Sparkles className="w-4 h-4" />
              <span className="text-sm">Tecnologia Revolucionária</span>
            </div>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-4xl md:text-5xl mb-6"
          >
            <span className="bg-gradient-to-r from-emerald-600 via-blue-600 to-purple-600 bg-clip-text text-transparent">
              Comparativo de Desempenho
            </span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto"
          >
            A solução mais avançada em impermeabilização sustentável do mercado, 
            com certificações internacionais e tecnologia à base de resina vegetal
          </motion.p>
        </motion.div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {advantages.map((advantage, index) => {
            const Icon = advantage.icon;
            
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ 
                  duration: 0.5, 
                  delay: index * 0.1,
                  ease: "easeOut"
                }}
                whileHover={{ y: -8, transition: { duration: 0.2 } }}
                className="group"
              >
                <div className="relative h-full p-8 bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100 overflow-hidden">
                  {/* Gradient Background on Hover */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${advantage.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`} />
                  
                  {/* Icon */}
                  <div className="relative mb-6">
                    <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${advantage.color} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    
                    {/* Metric Badge */}
                    <div className="absolute -top-2 -right-2 bg-white rounded-full shadow-lg px-4 py-2 border-2 border-emerald-500">
                      <span className={`bg-gradient-to-r ${advantage.color} bg-clip-text text-transparent`}>
                        {advantage.metric}
                      </span>
                    </div>
                  </div>

                  {/* Content */}
                  <h3 className="mb-3 text-gray-900">
                    {advantage.title}
                  </h3>
                  <p className="text-gray-600 mb-6">
                    {advantage.description}
                  </p>

                  {/* Details List */}
                  <div className="space-y-2">
                    {advantage.details.map((detail, i) => (
                      <div key={i} className="flex items-center gap-2 text-sm text-gray-700">
                        <CheckCircle2 className={`w-4 h-4 text-emerald-500`} />
                        <span>{detail}</span>
                      </div>
                    ))}
                  </div>

                  {/* Decorative Elements */}
                  <div className="absolute bottom-0 right-0 w-32 h-32 opacity-5">
                    <Icon className="w-full h-full text-gray-900" />
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Comparison Section */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 border border-gray-100"
        >
          <div className="text-center mb-12">
            <h3 className="text-3xl mb-4 text-gray-900">
              EcoConstruction vs Métodos Tradicionais
            </h3>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Veja a diferença em números reais de performance e economia
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            {/* Traditional Method */}
            <div className="bg-gray-50 rounded-2xl p-8 border-2 border-gray-200">
              <div className="text-center mb-6">
                <div className="inline-block px-4 py-2 bg-red-100 text-red-700 rounded-full text-sm mb-2">
                  Método Tradicional
                </div>
              </div>
              
              <div className="space-y-4">
                {[
                  { label: 'Tempo de Aplicação', value: 100, color: 'bg-red-500' },
                  { label: 'Custo Total', value: 100, color: 'bg-red-500' },
                  { label: 'Emissão de VOC', value: 85, color: 'bg-red-600' },
                  { label: 'Necessidade de Manutenção', value: 70, color: 'bg-red-400' },
                  { label: 'Complexidade de Aplicação', value: 90, color: 'bg-red-500' }
                ].map((item, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                  >
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-700">{item.label}</span>
                      <span className="text-gray-900">{item.value}%</span>
                    </div>
                    <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                      <motion.div 
                        className={`h-full ${item.color} rounded-full`}
                        initial={{ width: 0 }}
                        whileInView={{ width: `${item.value}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, delay: i * 0.1 }}
                      />
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* EcoConstruction Method */}
            <div className="bg-gradient-to-br from-emerald-50 to-blue-50 rounded-2xl p-8 border-2 border-emerald-200">
              <div className="text-center mb-6">
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-100 text-emerald-700 rounded-full text-sm mb-2">
                  <Award className="w-4 h-4" />
                  EcoConstruction
                </div>
              </div>
              
              <div className="space-y-4">
                {[
                  { label: 'Tempo de Aplicação', value: 20, color: 'from-emerald-500 to-teal-500' },
                  { label: 'Custo Total', value: 60, color: 'from-emerald-500 to-blue-500' },
                  { label: 'Emissão de VOC', value: 0, color: 'from-green-500 to-emerald-500' },
                  { label: 'Necessidade de Manutenção', value: 5, color: 'from-emerald-500 to-cyan-500' },
                  { label: 'Complexidade de Aplicação', value: 15, color: 'from-blue-500 to-emerald-500' }
                ].map((item, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                  >
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-700">{item.label}</span>
                      <span className="text-emerald-700">{item.value}%</span>
                    </div>
                    <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                      <motion.div 
                        className={`h-full bg-gradient-to-r ${item.color} rounded-full`}
                        initial={{ width: 0 }}
                        whileInView={{ width: `${item.value}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, delay: i * 0.1 }}
                      />
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>

          {/* Savings Summary */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5 }}
            className="mt-8 p-6 bg-gradient-to-r from-emerald-500 to-blue-500 rounded-2xl text-white text-center"
          >
            <div className="text-sm mb-2 opacity-90">Economia Total Comprovada</div>
            <div className="text-4xl md:text-5xl mb-2">até 65%</div>
            <div className="text-sm opacity-90">em tempo, custo e impacto ambiental</div>
          </motion.div>
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-10 py-5 bg-gradient-to-r from-emerald-600 to-blue-600 text-white rounded-xl shadow-xl hover:shadow-2xl transition-all duration-300"
          >
            Solicite uma Demonstração Gratuita
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}
