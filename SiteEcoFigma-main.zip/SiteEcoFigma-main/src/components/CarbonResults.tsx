import { motion } from "motion/react";
import { 
  Download, 
  Leaf, 
  TrendingDown, 
  DollarSign, 
  Trees,
  Factory,
  Droplets,
  ArrowLeft,
  CheckCircle2,
  Award,
  BarChart3,
  FileText
} from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts";
import { jsPDF } from "jspdf";

interface CalculatorData {
  constructionType: string;
  area: number;
  currentMaterial: string;
  maintenanceFrequency: string;
  location: string;
}

interface CalculationResults {
  traditionalCO2: number;
  ecoCO2: number;
  savings: number;
  savingsPercentage: number;
  treesEquivalent: number;
  costSavings: number;
  maintenanceSavings: number;
}

interface CarbonResultsProps {
  results: CalculationResults;
  calculatorData: CalculatorData;
  email: string;
  onBack: () => void;
}

export function CarbonResults({ results, calculatorData, email, onBack }: CarbonResultsProps) {
  const scrollToContact = () => {
    const element = document.getElementById("contato");
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };
  const chartData = [
    {
      name: "Material Tradicional",
      CO2: results.traditionalCO2,
      fill: "#ef4444",
    },
    {
      name: "EcoConstruction",
      CO2: results.ecoCO2,
      fill: "#10b981",
    },
  ];

  const savingsData = [
    { name: "Economia de CO₂", value: results.savings, fill: "#10b981" },
    { name: "Emissão Restante", value: results.ecoCO2, fill: "#94a3b8" },
  ];

  const yearlySavings = Array.from({ length: 10 }, (_, i) => ({
    year: `Ano ${i + 1}`,
    cumulativeSavings: Math.round(results.savings * (i + 1)),
    cumulativeCost: Math.round((results.costSavings + results.maintenanceSavings) * (i + 1)),
  }));

  const handleDownloadPDF = () => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    let yPos = 20;

    // Helper function to add new page if needed
    const checkPageBreak = (requiredSpace: number) => {
      if (yPos + requiredSpace > pageHeight - 20) {
        doc.addPage();
        yPos = 20;
        return true;
      }
      return false;
    };

    // Header with gradient effect (simulated)
    doc.setFillColor(16, 185, 129); // Emerald
    doc.rect(0, 0, pageWidth, 40, 'F');
    
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(24);
    doc.text('RELATORIO DE PEGADA DE CARBONO', pageWidth / 2, 20, { align: 'center' });
    
    doc.setFontSize(12);
    doc.text('EcoConstruction - Impermeabilizacao Sustentavel', pageWidth / 2, 30, { align: 'center' });

    yPos = 50;
    doc.setTextColor(0, 0, 0);

    // Date and Email
    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(`Data: ${new Date().toLocaleDateString('pt-BR')}`, 20, yPos);
    yPos += 6;
    doc.text(`Email: ${email}`, 20, yPos);
    yPos += 15;

    // Project Data Section
    doc.setFillColor(240, 240, 240);
    doc.rect(15, yPos - 5, pageWidth - 30, 8, 'F');
    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text('DADOS DO PROJETO', 20, yPos);
    yPos += 12;

    doc.setFontSize(10);
    doc.setTextColor(60, 60, 60);
    
    const projectData = [
      { label: 'Tipo de Construcao:', value: getConstructionTypeLabel(calculatorData.constructionType) },
      { label: 'Area Total:', value: `${calculatorData.area} m²` },
      { label: 'Material Atual:', value: getMaterialLabel(calculatorData.currentMaterial) },
      { label: 'Frequencia de Manutencao:', value: getMaintenanceLabel(calculatorData.maintenanceFrequency) },
      { label: 'Localizacao:', value: calculatorData.location }
    ];

    projectData.forEach(item => {
      doc.text(item.label, 25, yPos);
      doc.setTextColor(0, 0, 0);
      doc.text(item.value, 80, yPos);
      doc.setTextColor(60, 60, 60);
      yPos += 7;
    });

    yPos += 10;
    checkPageBreak(60);

    // Results Section
    doc.setFillColor(240, 240, 240);
    doc.rect(15, yPos - 5, pageWidth - 30, 8, 'F');
    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text('RESULTADOS DA ANALISE', 20, yPos);
    yPos += 15;

    // Main Stats Boxes
    const stats = [
      { 
        label: 'Material Tradicional', 
        value: `${results.traditionalCO2} kg CO₂`, 
        color: [239, 68, 68] 
      },
      { 
        label: 'EcoConstruction', 
        value: `${results.ecoCO2} kg CO₂`, 
        color: [16, 185, 129] 
      },
      { 
        label: 'Reducao Total', 
        value: `${results.savings} kg (${results.savingsPercentage}%)`, 
        color: [59, 130, 246] 
      }
    ];

    stats.forEach((stat, index) => {
      const xPos = 20 + (index * 60);
      
      doc.setFillColor(stat.color[0], stat.color[1], stat.color[2]);
      doc.roundedRect(xPos, yPos, 55, 25, 3, 3, 'F');
      
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(8);
      doc.text(stat.label, xPos + 27.5, yPos + 8, { align: 'center' });
      
      doc.setFontSize(11);
      doc.text(stat.value, xPos + 27.5, yPos + 18, { align: 'center' });
    });

    yPos += 35;
    checkPageBreak(50);

    // Environmental Impact
    doc.setFillColor(240, 240, 240);
    doc.rect(15, yPos - 5, pageWidth - 30, 8, 'F');
    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text('IMPACTO AMBIENTAL', 20, yPos);
    yPos += 12;

    doc.setFontSize(10);
    doc.setTextColor(60, 60, 60);
    doc.text(`Equivalente a plantar ${results.treesEquivalent} arvores`, 25, yPos);
    yPos += 7;
    doc.text(`Reducao de ${results.savingsPercentage}% nas emissoes de CO₂`, 25, yPos);
    yPos += 7;
    doc.text('Contribuicao significativa para metas de sustentabilidade corporativa', 25, yPos);
    
    yPos += 15;
    checkPageBreak(50);

    // Financial Savings
    doc.setFillColor(240, 240, 240);
    doc.rect(15, yPos - 5, pageWidth - 30, 8, 'F');
    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text('ECONOMIA FINANCEIRA', 20, yPos);
    yPos += 12;

    doc.setFontSize(10);
    doc.setTextColor(60, 60, 60);
    
    const financialData = [
      { label: 'Economia em Material:', value: `R$ ${results.costSavings.toLocaleString('pt-BR')}` },
      { label: 'Economia em Manutencao:', value: `R$ ${results.maintenanceSavings.toLocaleString('pt-BR')}` },
      { label: 'Economia Total:', value: `R$ ${(results.costSavings + results.maintenanceSavings).toLocaleString('pt-BR')}` }
    ];

    financialData.forEach(item => {
      doc.text(item.label, 25, yPos);
      doc.setFontSize(11);
      doc.setTextColor(16, 185, 129);
      doc.text(item.value, 80, yPos);
      doc.setFontSize(10);
      doc.setTextColor(60, 60, 60);
      yPos += 7;
    });

    yPos += 15;
    checkPageBreak(60);

    // 10 Year Projection
    doc.setFillColor(240, 240, 240);
    doc.rect(15, yPos - 5, pageWidth - 30, 8, 'F');
    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text('PROJECAO 10 ANOS', 20, yPos);
    yPos += 12;

    doc.setFontSize(10);
    doc.setTextColor(60, 60, 60);
    doc.text(`Economia Total CO₂: ${(results.savings * 10).toLocaleString('pt-BR')} kg`, 25, yPos);
    yPos += 7;
    doc.text(`Economia Total Financeira: R$ ${((results.costSavings + results.maintenanceSavings) * 10).toLocaleString('pt-BR')}`, 25, yPos);
    yPos += 7;
    doc.text(`Equivalente a ${results.treesEquivalent * 10} arvores plantadas`, 25, yPos);

    yPos += 15;
    checkPageBreak(70);

    // Certifications
    doc.setFillColor(240, 240, 240);
    doc.rect(15, yPos - 5, pageWidth - 30, 8, 'F');
    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text('CERTIFICACOES ECOCONSTRUCTION', 20, yPos);
    yPos += 12;

    doc.setFontSize(10);
    const certifications = [
      'NBR 9952 - Impermeabilizacao de Estruturas',
      'ASTM D6083 - Resistencia e Durabilidade',
      'ISO 14001 - Gestao Ambiental',
      'Produto 100% Atoxico e Sem Odor',
      'Materia-Prima de Fonte Renovavel'
    ];

    certifications.forEach(cert => {
      doc.setTextColor(16, 185, 129);
      doc.text('✓', 25, yPos);
      doc.setTextColor(60, 60, 60);
      doc.text(cert, 32, yPos);
      yPos += 7;
    });

    yPos += 15;
    checkPageBreak(50);

    // Recommendations
    doc.setFillColor(240, 240, 240);
    doc.rect(15, yPos - 5, pageWidth - 30, 8, 'F');
    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text('PROXIMOS PASSOS', 20, yPos);
    yPos += 12;

    doc.setFontSize(10);
    const steps = [
      '1. Entre em contato com nossa equipe tecnica',
      '2. Solicite uma visita tecnica gratuita',
      '3. Receba um orcamento personalizado',
      '4. Inicie a transformacao sustentavel do seu projeto'
    ];

    steps.forEach(step => {
      doc.setTextColor(60, 60, 60);
      doc.text(step, 25, yPos);
      yPos += 7;
    });

    yPos += 15;

    // Contact Information
    doc.setFillColor(16, 185, 129);
    doc.rect(15, yPos - 5, pageWidth - 30, 30, 'F');
    
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(12);
    doc.text('INFORMACOES DE CONTATO', pageWidth / 2, yPos + 5, { align: 'center' });
    
    doc.setFontSize(9);
    doc.text('Website: www.ecoconstruction.com.br', pageWidth / 2, yPos + 12, { align: 'center' });
    doc.text('Email: contato@ecoconstruction.com.br', pageWidth / 2, yPos + 18, { align: 'center' });
    doc.text('Telefone: (11) 9999-9999', pageWidth / 2, yPos + 24, { align: 'center' });

    // Footer
    doc.setFontSize(8);
    doc.setTextColor(150, 150, 150);
    doc.text('© 2025 EcoConstruction - Impermeabilizacao Sustentavel', pageWidth / 2, pageHeight - 10, { align: 'center' });

    // Save PDF
    doc.save(`Relatorio-Carbono-EcoConstruction-${Date.now()}.pdf`);
  };

  const getConstructionTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      residential: "Residencial",
      commercial: "Comercial",
      industrial: "Industrial",
      infrastructure: "Infraestrutura",
    };
    return labels[type] || type;
  };

  const getMaterialLabel = (material: string) => {
    const labels: Record<string, string> = {
      asphalt: "Manta Asfáltica",
      pvc: "Membrana PVC",
      polyurethane: "Poliuretano",
      acrylic: "Acrílico",
    };
    return labels[material] || material;
  };

  const getMaintenanceLabel = (frequency: string) => {
    const labels: Record<string, string> = {
      monthly: "Mensal",
      quarterly: "Trimestral",
      semiannual: "Semestral",
      annual: "Anual",
      rarely: "Raramente",
    };
    return labels[frequency] || frequency;
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Success Banner */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden bg-gradient-to-r from-emerald-500 via-blue-500 to-purple-500 text-white p-8 rounded-3xl shadow-2xl"
      >
        <div className="absolute inset-0 bg-black/10" />
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-6">
          <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center flex-shrink-0">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <div className="flex-1 text-center md:text-left">
            <h3 className="text-2xl mb-2">✓ Email Verificado com Sucesso!</h3>
            <p className="text-emerald-50 text-lg">
              Relatório completo enviado para <strong>{email}</strong>
            </p>
          </div>
          <Button
            onClick={handleDownloadPDF}
            className="bg-white text-emerald-600 hover:bg-emerald-50 shadow-lg px-6 py-6 text-lg flex-shrink-0"
          >
            <Download className="mr-2 w-5 h-5" />
            Baixar Relatório PDF
          </Button>
        </div>
      </motion.div>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          whileHover={{ scale: 1.05 }}
        >
          <Card className="p-6 bg-gradient-to-br from-red-50 to-red-100 border-red-200 h-full relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 opacity-10">
              <Factory className="w-full h-full" />
            </div>
            <Factory className="w-10 h-10 text-red-600 mb-3 relative z-10" />
            <p className="text-sm text-gray-700 mb-1">Material Tradicional</p>
            <p className="text-3xl text-red-600 mb-1">{results.traditionalCO2}</p>
            <p className="text-xs text-gray-600">kg de CO₂</p>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          whileHover={{ scale: 1.05 }}
        >
          <Card className="p-6 bg-gradient-to-br from-emerald-50 to-emerald-100 border-emerald-200 h-full relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 opacity-10">
              <Leaf className="w-full h-full" />
            </div>
            <Leaf className="w-10 h-10 text-emerald-600 mb-3 relative z-10" />
            <p className="text-sm text-gray-700 mb-1">EcoConstruction</p>
            <p className="text-3xl text-emerald-600 mb-1">{results.ecoCO2}</p>
            <p className="text-xs text-gray-600">kg de CO₂</p>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          whileHover={{ scale: 1.05 }}
        >
          <Card className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200 h-full relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 opacity-10">
              <TrendingDown className="w-full h-full" />
            </div>
            <TrendingDown className="w-10 h-10 text-blue-600 mb-3 relative z-10" />
            <p className="text-sm text-gray-700 mb-1">Redução</p>
            <p className="text-3xl text-blue-600 mb-1">{results.savingsPercentage}%</p>
            <p className="text-xs text-gray-600">{results.savings} kg economizados</p>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          whileHover={{ scale: 1.05 }}
        >
          <Card className="p-6 bg-gradient-to-br from-green-50 to-green-100 border-green-200 h-full relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 opacity-10">
              <Trees className="w-full h-full" />
            </div>
            <Trees className="w-10 h-10 text-green-600 mb-3 relative z-10" />
            <p className="text-sm text-gray-700 mb-1">Equivalente a</p>
            <p className="text-3xl text-green-600 mb-1">{results.treesEquivalent}</p>
            <p className="text-xs text-gray-600">árvores plantadas</p>
          </Card>
        </motion.div>
      </div>

      {/* Charts Section */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Bar Chart */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="p-6 backdrop-blur-xl bg-white border-gray-200 shadow-xl">
            <h4 className="mb-4 flex items-center gap-2 text-lg">
              <BarChart3 className="text-emerald-600" />
              Comparação de Emissões
            </h4>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Bar dataKey="CO2" radius={[8, 8, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </motion.div>

        {/* Pie Chart */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Card className="p-6 backdrop-blur-xl bg-white border-gray-200 shadow-xl">
            <h4 className="mb-4 flex items-center gap-2 text-lg">
              <Droplets className="text-blue-600" />
              Distribuição de CO₂
            </h4>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie
                  data={savingsData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={90}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {savingsData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </Card>
        </motion.div>
      </div>

      {/* Financial Savings */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
      >
        <Card className="p-8 backdrop-blur-xl bg-white border-gray-200 shadow-xl">
          <h4 className="text-2xl mb-6 flex items-center gap-2">
            <DollarSign className="text-emerald-600" />
            Economia Financeira Detalhada
          </h4>
          
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            {[
              { label: "Economia em Material", value: results.costSavings, color: "from-emerald-500 to-teal-500" },
              { label: "Economia em Manutenção", value: results.maintenanceSavings, color: "from-blue-500 to-cyan-500" },
              { label: "Economia Total", value: results.costSavings + results.maintenanceSavings, color: "from-purple-500 to-pink-500" }
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.8 + index * 0.1 }}
                className="p-6 bg-gradient-to-br from-gray-50 to-white rounded-2xl border-2 border-gray-200 hover:border-emerald-300 transition-colors"
              >
                <p className="text-sm text-gray-600 mb-2">{item.label}</p>
                <p className={`text-3xl bg-gradient-to-r ${item.color} bg-clip-text text-transparent`}>
                  R$ {item.value.toLocaleString('pt-BR')}
                </p>
              </motion.div>
            ))}
          </div>

          <h5 className="mb-4 text-lg">Projeção de Economia em 10 Anos</h5>
          <ResponsiveContainer width="100%" height={320}>
            <LineChart data={yearlySavings}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="year" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Legend />
              <Line
                type="monotone"
                dataKey="cumulativeSavings"
                stroke="#10b981"
                strokeWidth={3}
                name="Economia CO₂ (kg)"
                dot={{ fill: "#10b981", r: 4 }}
              />
              <Line
                type="monotone"
                dataKey="cumulativeCost"
                stroke="#3b82f6"
                strokeWidth={3}
                name="Economia Financeira (R$)"
                dot={{ fill: "#3b82f6", r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </motion.div>

      {/* Project Details */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
      >
        <Card className="p-8 backdrop-blur-xl bg-white border-gray-200 shadow-xl">
          <h4 className="text-2xl mb-6 flex items-center gap-2">
            <FileText className="text-blue-600" />
            Detalhes do Projeto Analisado
          </h4>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h5 className="mb-4 text-lg text-gray-700 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                Informações Básicas
              </h5>
              <div className="space-y-3">
                {[
                  { label: "Tipo de Construção", value: getConstructionTypeLabel(calculatorData.constructionType) },
                  { label: "Área Total", value: `${calculatorData.area} m²` },
                  { label: "Localização", value: calculatorData.location }
                ].map((item, index) => (
                  <div key={index} className="flex justify-between py-3 border-b border-gray-200">
                    <span className="text-gray-600">{item.label}:</span>
                    <span className="text-gray-900">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h5 className="mb-4 text-lg text-gray-700 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-blue-600" />
                Análise Comparativa
              </h5>
              <div className="space-y-3">
                {[
                  { label: "Material Atual", value: getMaterialLabel(calculatorData.currentMaterial) },
                  { label: "Manutenção Atual", value: getMaintenanceLabel(calculatorData.maintenanceFrequency) },
                  { label: "Data da Análise", value: new Date().toLocaleDateString('pt-BR') }
                ].map((item, index) => (
                  <div key={index} className="flex justify-between py-3 border-b border-gray-200">
                    <span className="text-gray-600">{item.label}:</span>
                    <span className="text-gray-900">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Card>
      </motion.div>

      {/* Certifications */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.9 }}
      >
        <Card className="p-8 backdrop-blur-xl bg-gradient-to-br from-emerald-50 via-blue-50 to-purple-50 border-emerald-200 shadow-xl">
          <div className="flex flex-col md:flex-row items-start gap-6">
            <div className="w-16 h-16 bg-gradient-to-br from-emerald-400 to-blue-400 rounded-2xl flex items-center justify-center flex-shrink-0">
              <Award className="w-8 h-8 text-white" />
            </div>
            <div className="flex-1">
              <h4 className="text-2xl mb-6">Certificações e Diferenciais EcoConstruction</h4>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  "NBR 9952 - Impermeabilização de Estruturas",
                  "ASTM D6083 - Resistência e Durabilidade",
                  "ISO 14001 - Sistema de Gestão Ambiental",
                  "100% Atóxico e Sem Odor",
                  "Matéria-Prima de Fonte Renovável",
                  "Zero Emissões de VOC"
                ].map((cert, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 1 + index * 0.05 }}
                    className="flex items-center gap-3 p-3 bg-white rounded-lg"
                  >
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                    <span className="text-sm text-gray-700">{cert}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </Card>
      </motion.div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center pt-8">
        <Button
          variant="outline"
          onClick={onBack}
          className="w-full sm:w-auto border-2"
        >
          <ArrowLeft className="mr-2 w-4 h-4" />
          Nova Análise
        </Button>

        <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
          <Button
            onClick={handleDownloadPDF}
            className="flex-1 sm:flex-none bg-gradient-to-r from-emerald-600 to-blue-600 hover:from-emerald-700 hover:to-blue-700 text-white shadow-lg hover:shadow-xl transition-all"
          >
            <Download className="mr-2 w-4 h-4" />
            Baixar Relatório PDF
          </Button>
          
          <Button 
            onClick={scrollToContact}
            className="flex-1 sm:flex-none bg-gradient-to-r from-[#3eada2] to-[#2d9186] hover:from-[#2d9186] hover:to-[#3eada2] text-white shadow-lg hover:shadow-xl transition-all"
          >
            Solicitar Orçamento
          </Button>
        </div>
      </div>
    </div>
  );
}
