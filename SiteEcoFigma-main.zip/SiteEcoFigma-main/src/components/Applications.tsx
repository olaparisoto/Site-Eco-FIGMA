import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { 
  Building2, 
  Droplets, 
  Factory, 
  Ship, 
  Zap, 
  TreePine,
  Home,
  Shield
} from "lucide-react";

export function Applications() {
  const applications = [
    {
      category: "Industrial",
      icon: Factory,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200",
      uses: [
        "Pisos industriais contra corrosão e abrasão",
        "Estações de Tratamento de Efluentes (ETE/ETA)",
        "Contenção de químicos e canaletas",
        "Tanques e silos metálicos",
        "Câmaras frias e áreas sanitárias",
        "Tratamento contra agressão química"
      ]
    },
    {
      category: "Infraestrutura",
      icon: Building2,
      color: "text-gray-600",
      bgColor: "bg-gray-50",
      borderColor: "border-gray-200",
      uses: [
        "Reservatórios de água potável",
        "Caixas d'água de grande porte",
        "Lajes de cobertura e marquises",
        "Terraços e floreiras",
        "Juntas de dilatação",
        "Tratamento de umidade ascendente"
      ]
    },
    {
      category: "Aquático",
      icon: Droplets,
      color: "text-cyan-600",
      bgColor: "bg-cyan-50",
      borderColor: "border-cyan-200",
      uses: [
        "Piscinas comerciais e residenciais",
        "Grandes aquários e espelhos d'água",
        "Tanques para piscicultura",
        "Impermeabilização de telhado verde",
        "Sistemas de irrigação",
        "Reservatórios de água"
      ]
    },
    {
      category: "Marinho",
      icon: Ship,
      color: "text-teal-600",
      bgColor: "bg-teal-50",
      borderColor: "border-teal-200",
      uses: [
        "Embarcações e cascos de navios",
        "Docas e estruturas portuárias",
        "Píeres e zonas de respingo",
        "Estruturas submersas",
        "Proteção contra água salgada",
        "Ambientes marinhos severos"
      ]
    },
    {
      category: "Metálico",
      icon: Zap,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
      borderColor: "border-orange-200",
      uses: [
        "Telhados metálicos e fibrocimento",
        "Estruturas metálicas expostas",
        "Calhas, rufos e condutores",
        "Equipamentos sujeitos à corrosão",
        "Tanques de combustível",
        "Proteção anticorrosiva definitiva"
      ]
    },
    {
      category: "Madeira",
      icon: TreePine,
      color: "text-green-600",
      bgColor: "bg-green-50",
      borderColor: "border-green-200",
      uses: [
        "Estruturas de madeira externa",
        "Decks e pergolados",
        "Móveis de jardim",
        "Proteção contra umidade e fungos",
        "Artesanato e elementos decorativos",
        "Conservação de madeiras nobres"
      ]
    }
  ];

  const industries = [
    {
      name: "Sucroenergetica",
      description: "Usinas de açúcar e álcool com alta agressividade química",
      applications: ["Pisos de produção", "Tanques de fermentação", "Áreas de lavagem"]
    },
    {
      name: "Química e Petroquímica",
      description: "Indústrias com produtos altamente corrosivos",
      applications: ["Contenção de químicos", "Pisos industriais", "Tanques de armazenamento"]
    },
    {
      name: "Alimentícia",
      description: "Segurança alimentar e facilidade de limpeza",
      applications: ["Pisos de produção", "Câmaras frias", "Áreas de higienização"]
    },
    {
      name: "Saneamento",
      description: "Estações de tratamento de água e esgoto",
      applications: ["ETEs e ETAs", "Reservatórios", "Canais e canaletas"]
    },
    {
      name: "Portuária",
      description: "Ambientes marinhos com alta salinidade",
      applications: ["Docas e píeres", "Armazéns portuários", "Estruturas metálicas"]
    },
    {
      name: "Shopping Centers",
      description: "Grandes áreas com tráfego intenso",
      applications: ["Garagens subterrâneas", "Coberturas", "Áreas externas"]
    }
  ];

  return (
    <section id="aplicacoes" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-blue-100 text-blue-800 hover:bg-blue-100">
            Aplicações Industriais
          </Badge>
          <h2 className="text-3xl lg:text-4xl mb-4 text-gray-900">
            Soluções para <span className="text-blue-600">Todos os Setores</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Da indústria pesada aos ambientes marinhos, nossos produtos atendem 
            as mais diversas necessidades de impermeabilização e proteção.
          </p>
        </div>

        {/* Applications by Category */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {applications.map((app, index) => {
            const IconComponent = app.icon;
            return (
              <Card key={index} className={`hover:shadow-lg transition-shadow border-2 ${app.borderColor} bg-white`}>
                <CardHeader>
                  <div className={`w-12 h-12 ${app.bgColor} rounded-lg flex items-center justify-center mb-4`}>
                    <IconComponent className={`h-6 w-6 ${app.color}`} />
                  </div>
                  <CardTitle className={`text-xl ${app.color}`}>{app.category}</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {app.uses.map((use, idx) => (
                      <li key={idx} className="flex items-start space-x-3">
                        <div className={`w-1.5 h-1.5 ${app.bgColor} rounded-full mt-2 flex-shrink-0`}></div>
                        <span className="text-sm text-gray-600 leading-relaxed">{use}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Industry Sectors */}
        <div className="bg-gradient-to-br from-gray-50 to-blue-50 rounded-2xl p-8">
          <div className="text-center mb-12">
            <h3 className="text-2xl mb-4 text-gray-900">
              Setores que Confiam na EcoConstruction
            </h3>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Profissionais de diversos segmentos já descobriram as vantagens 
              de nossos produtos ecológicos e de alta performance.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {industries.map((industry, index) => (
              <div key={index} className="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-start space-x-3 mb-4">
                  <Shield className="h-6 w-6 text-blue-600 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900">{industry.name}</h4>
                    <p className="text-sm text-gray-600 mt-1">{industry.description}</p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  {industry.applications.map((app, idx) => (
                    <Badge key={idx} variant="secondary" className="bg-blue-50 text-blue-700 text-xs">
                      {app}
                    </Badge>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Technical Standards Section */}
        <div className="mt-16 bg-white border-2 border-green-200 rounded-2xl p-8">
          <div className="text-center mb-8">
            <h3 className="text-2xl mb-4 text-gray-900">
              Certificações e Normas Técnicas
            </h3>
            <p className="text-gray-600">
              Nossos produtos atendem rigorosamente às principais normas brasileiras e internacionais
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { code: "NBR 12170:2009", title: "Potabilidade da água", desc: "Sistema de Impermeabilização" },
              { code: "NBR 15487:2007", title: "Membrana Poliuretano", desc: "Para Impermeabilização" },
              { code: "NBR 9575:2010", title: "Impermeabilização", desc: "Seleção e Projeto" },
              { code: "ASTM C-267:2012", title: "Resistência Química", desc: "Padrões Internacionais" },
              { code: "NBR 10787:2011", title: "Estanqueidade", desc: "Penetração de água sob pressão" },
              { code: "ASTM D-4060:2014", title: "Resistência Abrasão", desc: "Durabilidade Comprovada" },
              { code: "ISO 14000", title: "Gestão Ambiental", desc: "Produtos Sustentáveis" },
              { code: "NBR 7215:2014", title: "Resistência Compressão", desc: "Qualidade Estrutural" }
            ].map((norm, index) => (
              <div key={index} className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-green-600 font-bold text-sm mb-2">{norm.code}</div>
                <div className="font-semibold text-gray-900 text-sm mb-1">{norm.title}</div>
                <div className="text-xs text-gray-600">{norm.desc}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl p-8 text-white">
            <h3 className="text-2xl mb-4">
              Sua Empresa Precisa de Impermeabilização Profissional?
            </h3>
            <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
              Nossos especialistas estão prontos para analisar sua necessidade específica 
              e recomendar a melhor solução EcoConstruction para seu projeto.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                Falar com Especialista
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
                Solicitar Visita Técnica
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}