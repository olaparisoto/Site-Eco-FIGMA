import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Leaf, 
  Factory, 
  TrendingDown, 
  Mail, 
  CheckCircle2, 
  ArrowRight,
  ArrowLeft,
  Calculator,
  Building2,
  Droplets,
  Wrench,
  Shield,
  Sparkles,
  Lock,
  Unlock
} from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card } from "./ui/card";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { CarbonResults } from "./CarbonResults";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";

interface CalculatorData {
  constructionType: string;
  area: number;
  currentMaterial: string;
  maintenanceFrequency: string;
  location: string;
}

interface CalculationResults {
  traditionalCO2: number;
  ecoCO2: number;
  savings: number;
  savingsPercentage: number;
  treesEquivalent: number;
  costSavings: number;
  maintenanceSavings: number;
}

export function CarbonCalculator() {
  const [step, setStep] = useState(1);
  const [calculatorData, setCalculatorData] = useState<CalculatorData>({
    constructionType: "",
    area: 0,
    currentMaterial: "",
    maintenanceFrequency: "",
    location: "",
  });
  const [email, setEmail] = useState("");
  const [verificationCode, setVerificationCode] = useState("");
  const [sentCode, setSentCode] = useState("");
  const [isVerified, setIsVerified] = useState(false);
  const [results, setResults] = useState<CalculationResults | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  // Função para calcular a pegada de carbono
  const calculateCarbonFootprint = (): CalculationResults => {
    const { area, currentMaterial, maintenanceFrequency, constructionType } = calculatorData;

    // Fatores de emissão (kg CO2 por m²)
    const traditionalFactors: Record<string, number> = {
      asphalt: 15.5,
      pvc: 12.8,
      polyurethane: 11.2,
      acrylic: 9.5,
    };

    const ecoFactor = 2.3; // Resina vegetal tem emissão muito menor

    // Multiplicadores por tipo de construção
    const constructionMultipliers: Record<string, number> = {
      residential: 1.0,
      commercial: 1.2,
      industrial: 1.5,
      infrastructure: 1.8,
    };

    // Multiplicadores de manutenção
    const maintenanceMultipliers: Record<string, number> = {
      monthly: 3.0,
      quarterly: 2.0,
      semiannual: 1.5,
      annual: 1.2,
      rarely: 1.0,
    };

    const traditionalFactor = traditionalFactors[currentMaterial] || 12;
    const constructionMultiplier = constructionMultipliers[constructionType] || 1;
    const maintenanceMultiplier = maintenanceMultipliers[maintenanceFrequency] || 1;

    // Cálculo de CO2
    const traditionalCO2 = area * traditionalFactor * constructionMultiplier * maintenanceMultiplier;
    const ecoCO2 = area * ecoFactor * constructionMultiplier;
    const savings = traditionalCO2 - ecoCO2;
    const savingsPercentage = (savings / traditionalCO2) * 100;

    // Equivalência em árvores (1 árvore absorve ~22kg CO2/ano)
    const treesEquivalent = Math.round(savings / 22);

    // Economia de custos (estimativa)
    const costSavings = area * 35; // R$ por m²
    const maintenanceSavings = area * 15 * maintenanceMultipliers[maintenanceFrequency];

    return {
      traditionalCO2: Math.round(traditionalCO2),
      ecoCO2: Math.round(ecoCO2),
      savings: Math.round(savings),
      savingsPercentage: Math.round(savingsPercentage),
      treesEquivalent,
      costSavings: Math.round(costSavings),
      maintenanceSavings: Math.round(maintenanceSavings),
    };
  };

  const handleCalculate = () => {
    setIsCalculating(true);
    setTimeout(() => {
      const calculatedResults = calculateCarbonFootprint();
      setResults(calculatedResults);
      setIsCalculating(false);
      setStep(2);
    }, 1500);
  };

  const handleSendCode = () => {
    // Simular envio de código
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setSentCode(code);
    
    // Mostrar o código no console (em produção, seria enviado por email)
    console.log("Código de verificação:", code);
    alert(`✓ Código de verificação enviado!\n\nPara esta demonstração, use o código: ${code}`);
  };

  const handleVerifyCode = () => {
    if (verificationCode === sentCode) {
      setIsVerified(true);
      setStep(3);
    } else {
      alert("❌ Código inválido! Por favor, tente novamente.");
    }
  };

  const isStep1Valid = () => {
    return (
      calculatorData.constructionType !== "" &&
      calculatorData.area > 0 &&
      calculatorData.currentMaterial !== "" &&
      calculatorData.maintenanceFrequency !== "" &&
      calculatorData.location !== ""
    );
  };

  const isEmailValid = () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const progressPercentage = (step / 3) * 100;

  return (
    <section id="calculadora" className="relative py-32 overflow-hidden bg-gradient-to-b from-white via-emerald-50/30 to-blue-50/30">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div 
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.2, 0.3]
          }}
          transition={{ duration: 8, repeat: Infinity }}
          className="absolute top-20 left-10 w-96 h-96 bg-emerald-400/20 rounded-full blur-3xl" 
        />
        <motion.div 
          animate={{ 
            scale: [1, 1.1, 1],
            opacity: [0.2, 0.3, 0.2]
          }}
          transition={{ duration: 10, repeat: Infinity }}
          className="absolute bottom-20 right-10 w-[500px] h-[500px] bg-blue-400/20 rounded-full blur-3xl" 
        />
      </div>

      <div className="container mx-auto px-4 relative z-10 max-w-5xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="inline-block mb-6"
          >
            <Badge className="px-6 py-3 bg-gradient-to-r from-emerald-500 to-blue-500 text-white border-0 shadow-lg">
              <Calculator className="w-4 h-4 mr-2" />
              Calculadora de Impacto Ambiental
            </Badge>
          </motion.div>
          
          <h2 className="text-4xl md:text-6xl mb-6">
            <span className="bg-gradient-to-r from-emerald-600 via-blue-600 to-purple-600 bg-clip-text text-transparent">
              Calcule Sua Pegada de Carbono
            </span>
          </h2>
          
          <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
            Descubra quanto você pode economizar em emissões de CO₂ e custos 
            ao escolher nossa solução sustentável. Análise completa em 3 passos simples.
          </p>
        </motion.div>

        {/* Progress indicator */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="max-w-3xl mx-auto mb-12"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <span className="text-sm text-gray-600">
                Passo {step} de 3
              </span>
              <Badge variant="outline" className="text-xs">
                {step === 1 && "Dados do Projeto"}
                {step === 2 && "Verificação"}
                {step === 3 && "Resultados"}
              </Badge>
            </div>
            <span className="text-sm text-emerald-600">
              {Math.round(progressPercentage)}% completo
            </span>
          </div>
          
          <Progress value={progressPercentage} className="h-3" />
        </motion.div>

        <AnimatePresence mode="wait">
          {/* Step 1: Questionário */}
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.3 }}
              className="max-w-3xl mx-auto"
            >
              <Card className="p-8 md:p-12 backdrop-blur-xl bg-white/90 border-2 border-gray-200 shadow-2xl rounded-3xl">
                <div className="flex items-center gap-3 mb-8">
                  <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-blue-500 rounded-xl flex items-center justify-center">
                    <Building2 className="text-white w-6 h-6" />
                  </div>
                  <h3 className="text-2xl md:text-3xl">Informações do Projeto</h3>
                </div>

                <div className="space-y-8">
                  {/* Tipo de Construção */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                  >
                    <Label htmlFor="constructionType" className="flex items-center gap-2 mb-3 text-base">
                      <Building2 className="w-5 h-5 text-emerald-600" />
                      Tipo de Construção
                    </Label>
                    <Select
                      value={calculatorData.constructionType}
                      onValueChange={(value) =>
                        setCalculatorData({ ...calculatorData, constructionType: value })
                      }
                    >
                      <SelectTrigger className="h-12 bg-white/50 border-2">
                        <SelectValue placeholder="Selecione o tipo de construção" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="residential">🏠 Residencial</SelectItem>
                        <SelectItem value="commercial">🏢 Comercial</SelectItem>
                        <SelectItem value="industrial">🏭 Industrial</SelectItem>
                        <SelectItem value="infrastructure">🌉 Infraestrutura</SelectItem>
                      </SelectContent>
                    </Select>
                  </motion.div>

                  {/* Área */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                  >
                    <Label htmlFor="area" className="flex items-center gap-2 mb-3 text-base">
                      <Factory className="w-5 h-5 text-emerald-600" />
                      Área a Impermeabilizar (m²)
                    </Label>
                    <Input
                      id="area"
                      type="number"
                      min="0"
                      placeholder="Digite a área em metros quadrados"
                      value={calculatorData.area || ""}
                      onChange={(e) =>
                        setCalculatorData({ ...calculatorData, area: Number(e.target.value) })
                      }
                      className="h-12 bg-white/50 border-2 text-lg"
                    />
                  </motion.div>

                  {/* Material Atual */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                  >
                    <Label htmlFor="currentMaterial" className="flex items-center gap-2 mb-3 text-base">
                      <Droplets className="w-5 h-5 text-emerald-600" />
                      Material Tradicionalmente Usado
                    </Label>
                    <Select
                      value={calculatorData.currentMaterial}
                      onValueChange={(value) =>
                        setCalculatorData({ ...calculatorData, currentMaterial: value })
                      }
                    >
                      <SelectTrigger className="h-12 bg-white/50 border-2">
                        <SelectValue placeholder="Selecione o material atual" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="asphalt">Manta Asfáltica (mais poluente)</SelectItem>
                        <SelectItem value="pvc">Membrana PVC</SelectItem>
                        <SelectItem value="polyurethane">Poliuretano</SelectItem>
                        <SelectItem value="acrylic">Acrílico</SelectItem>
                      </SelectContent>
                    </Select>
                  </motion.div>

                  {/* Frequência de Manutenção */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                  >
                    <Label htmlFor="maintenance" className="flex items-center gap-2 mb-3 text-base">
                      <Wrench className="w-5 h-5 text-emerald-600" />
                      Frequência de Manutenção Atual
                    </Label>
                    <Select
                      value={calculatorData.maintenanceFrequency}
                      onValueChange={(value) =>
                        setCalculatorData({ ...calculatorData, maintenanceFrequency: value })
                      }
                    >
                      <SelectTrigger className="h-12 bg-white/50 border-2">
                        <SelectValue placeholder="Com que frequência precisa manutenção?" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="monthly">📅 Mensal (alta manutenção)</SelectItem>
                        <SelectItem value="quarterly">📅 Trimestral</SelectItem>
                        <SelectItem value="semiannual">📅 Semestral</SelectItem>
                        <SelectItem value="annual">📅 Anual</SelectItem>
                        <SelectItem value="rarely">📅 Raramente</SelectItem>
                      </SelectContent>
                    </Select>
                  </motion.div>

                  {/* Localização */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 }}
                  >
                    <Label htmlFor="location" className="flex items-center gap-2 mb-3 text-base">
                      <Shield className="w-5 h-5 text-emerald-600" />
                      Estado/Região
                    </Label>
                    <Input
                      id="location"
                      type="text"
                      placeholder="Ex: São Paulo, Rio de Janeiro..."
                      value={calculatorData.location}
                      onChange={(e) =>
                        setCalculatorData({ ...calculatorData, location: e.target.value })
                      }
                      className="h-12 bg-white/50 border-2 text-lg"
                    />
                  </motion.div>
                </div>

                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.6 }}
                  className="flex justify-end mt-10"
                >
                  <Button
                    onClick={handleCalculate}
                    disabled={!isStep1Valid() || isCalculating}
                    className="h-14 px-10 bg-gradient-to-r from-[#3eada2] to-[#2d9186] hover:from-[#2d9186] hover:to-[#3eada2] text-white text-lg shadow-2xl hover:shadow-3xl transition-all disabled:opacity-30 disabled:cursor-not-allowed font-semibold"
                  >
                    {isCalculating ? (
                      <>
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                          className="w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-2"
                        />
                        Calculando...
                      </>
                    ) : (
                      <>
                        Calcular Impacto
                        <ArrowRight className="ml-2 w-5 h-5" />
                      </>
                    )}
                  </Button>
                </motion.div>
              </Card>
            </motion.div>
          )}

          {/* Step 2: Resultados Parciais + Email */}
          {step === 2 && results && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.3 }}
              className="max-w-4xl mx-auto space-y-8"
            >
              {/* Preview com Lock */}
              <Card className="p-8 md:p-12 backdrop-blur-xl bg-white/90 border-2 border-gray-200 shadow-2xl rounded-3xl relative overflow-hidden">
                {/* Lock Overlay */}
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/80 to-white z-10 pointer-events-none backdrop-blur-sm" />
                
                <div className="relative">
                  <div className="flex items-center gap-3 mb-8">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center">
                      <TrendingDown className="text-white w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-2xl md:text-3xl">Prévia dos Resultados</h3>
                      <p className="text-gray-600 text-sm">Desbloqueie para ver análise completa</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    {[
                      { 
                        icon: Factory,
                        label: "Material Tradicional", 
                        value: `${results.traditionalCO2} kg`,
                        color: "from-red-500 to-red-600"
                      },
                      { 
                        icon: Leaf,
                        label: "EcoConstruction", 
                        value: `${results.ecoCO2} kg`,
                        color: "from-emerald-500 to-emerald-600"
                      },
                      { 
                        icon: TrendingDown,
                        label: "Você Economiza", 
                        value: `${results.savingsPercentage}%`,
                        color: "from-blue-500 to-blue-600"
                      }
                    ].map((stat, index) => {
                      const Icon = stat.icon;
                      return (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.1 }}
                          className="relative"
                        >
                          <div className={`p-6 bg-gradient-to-br ${stat.color} rounded-2xl shadow-lg`}>
                            <Icon className="w-8 h-8 text-white mb-3" />
                            <p className="text-sm text-white/80 mb-1">{stat.label}</p>
                            <p className="text-3xl text-white">{stat.value}</p>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>

                  {/* Blurred Content */}
                  <div className="blur-md opacity-40 pointer-events-none space-y-4">
                    <div className="h-48 bg-gradient-to-r from-emerald-100 to-blue-100 rounded-2xl" />
                    <div className="grid grid-cols-2 gap-4">
                      <div className="h-32 bg-gray-200 rounded-xl" />
                      <div className="h-32 bg-gray-200 rounded-xl" />
                    </div>
                  </div>

                  {/* Lock Icon Center */}
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
                    <motion.div
                      animate={{ scale: [1, 1.1, 1] }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="w-20 h-20 bg-gradient-to-br from-gray-700 to-gray-900 rounded-full flex items-center justify-center shadow-2xl"
                    >
                      <Lock className="w-10 h-10 text-white" />
                    </motion.div>
                  </div>
                </div>
              </Card>

              {/* Email Form */}
              <Card className="p-8 md:p-12 backdrop-blur-xl bg-white/90 border-2 border-emerald-200 shadow-2xl rounded-3xl">
                <div className="text-center mb-8">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", stiffness: 200 }}
                    className="w-20 h-20 bg-gradient-to-br from-emerald-400 to-blue-400 rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl"
                  >
                    <Mail className="w-10 h-10 text-white" />
                  </motion.div>
                  
                  <h3 className="text-2xl md:text-3xl mb-3">
                    Desbloqueie os Resultados Completos
                  </h3>
                  <p className="text-gray-600 text-lg max-w-2xl mx-auto">
                    Digite seu email profissional para receber um código de verificação 
                    e acessar o relatório detalhado com gráficos, análises e recomendações personalizadas
                  </p>
                </div>

                <div className="max-w-md mx-auto space-y-6">
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                  >
                    <Label htmlFor="email" className="text-base mb-2">Email Profissional</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="seu.email@empresa.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="h-12 bg-white/50 border-2 text-lg"
                    />
                  </motion.div>

                  <AnimatePresence>
                    {sentCode && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="space-y-6"
                      >
                        <div>
                          <Label htmlFor="code" className="text-base mb-2">Código de Verificação</Label>
                          <Input
                            id="code"
                            type="text"
                            placeholder="Digite o código de 6 dígitos"
                            value={verificationCode}
                            onChange={(e) => setVerificationCode(e.target.value)}
                            className="h-12 bg-white/50 border-2 text-lg text-center tracking-widest"
                            maxLength={6}
                          />
                          <p className="text-sm text-gray-500 mt-2 text-center">
                            ✓ Código enviado! Verifique seu email
                          </p>
                        </div>

                        <Button
                          onClick={handleVerifyCode}
                          disabled={verificationCode.length !== 6}
                          className="w-full h-14 bg-gradient-to-r from-[#3eada2] to-[#2d9186] hover:from-[#2d9186] hover:to-[#3eada2] text-white text-lg shadow-2xl hover:shadow-3xl transition-all disabled:opacity-30 disabled:cursor-not-allowed font-semibold"
                        >
                          <Unlock className="mr-2 w-5 h-5" />
                          Verificar e Desbloquear Resultados
                        </Button>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {!sentCode && (
                    <Button
                      onClick={handleSendCode}
                      disabled={!isEmailValid()}
                      className="w-full h-14 bg-gradient-to-r from-[#3eada2] to-[#2d9186] hover:from-[#2d9186] hover:to-[#3eada2] text-white text-lg shadow-2xl hover:shadow-3xl transition-all disabled:opacity-30 disabled:cursor-not-allowed font-semibold"
                    >
                      <Sparkles className="mr-2 w-5 h-5" />
                      Enviar Código de Verificação
                    </Button>
                  )}
                </div>

                <div className="flex justify-center mt-8">
                  <Button
                    variant="ghost"
                    onClick={() => setStep(1)}
                    className="text-gray-600 hover:text-gray-900"
                  >
                    <ArrowLeft className="mr-2 w-4 h-4" />
                    Voltar e ajustar dados
                  </Button>
                </div>
              </Card>
            </motion.div>
          )}

          {/* Step 3: Resultados Completos */}
          {step === 3 && results && isVerified && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.4 }}
            >
              <CarbonResults 
                results={results} 
                calculatorData={calculatorData}
                email={email}
                onBack={() => {
                  setStep(1);
                  setEmail("");
                  setVerificationCode("");
                  setSentCode("");
                  setIsVerified(false);
                }}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
