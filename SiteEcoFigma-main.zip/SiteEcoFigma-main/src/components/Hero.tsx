import { Button } from "./ui/button";
import { ArrowRight, Droplet } from "lucide-react";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import heroImage1 from "figma:asset/4d75fe21aba9456a06e8d152a7406cb2440d3256.png";
import heroImage2 from "figma:asset/3b4411015f74cc0b4ad24db3c8a2c23ad68bc7ba.png";
import heroImage3 from "figma:asset/4c01ec192aa38d87e302deacc4f9aeec81d0d17f.png";

export function Hero() {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const slides = [
    { image: heroImage1, alt: "Impermeabilização Industrial" },
    { image: heroImage2, alt: "Impermeabilização Definitiva" },
    { image: heroImage3, alt: "Proteção Total" }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 10000); // Troca a cada 10 segundos

    return () => clearInterval(interval);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  const scrollToContact = () => {
    scrollToSection("contato");
  };

  return (
    <section id="inicio" className="relative min-h-screen flex items-center overflow-hidden pt-20">
      {/* Animated Background Carousel with Ken Burns Effect */}
      <div className="absolute inset-0">
        <AnimatePresence mode="wait">
          {slides.map((slide, index) => 
            index === currentSlide && (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 1 }}
                animate={{ 
                  opacity: 1, 
                  scale: 1.1 // Ken Burns zoom effect
                }}
                exit={{ opacity: 0 }}
                transition={{ 
                  opacity: { duration: 2 },
                  scale: { duration: 10, ease: "linear" }
                }}
                className="absolute inset-0 bg-cover bg-center bg-no-repeat"
                style={{ backgroundImage: `url(${slide.image})` }}
              >
                {/* Dark overlays */}
                <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40"></div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/30"></div>
              </motion.div>
            )
          )}
        </AnimatePresence>
      </div>
      
      {/* Slide indicators */}
      <div className="absolute bottom-24 left-1/2 transform -translate-x-1/2 flex space-x-2 z-20">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`h-1.5 rounded-full transition-all duration-300 ${
              index === currentSlide 
                ? "w-8 bg-[#3eada2]" 
                : "w-1.5 bg-white/50 hover:bg-white/70"
            }`}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-8"
          >
            {/* Badge */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="inline-flex items-center space-x-2 bg-[#3eada2]/90 backdrop-blur-sm text-white px-5 py-2.5 rounded-full shadow-lg"
            >
              <Droplet className="h-5 w-5" />
              <span>O Futuro da Construção Sustentável</span>
            </motion.div>
            
            {/* Main Headline */}
            <div className="space-y-6">
              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="text-5xl lg:text-6xl xl:text-7xl text-white leading-tight"
              >
                <span className="block">Revestimento</span>
                <span className="block bg-gradient-to-r from-[#3eada2] via-[#2d9186] to-[#3eada2] bg-clip-text text-transparent drop-shadow-[0_0_30px_rgba(62,173,162,0.5)] animate-[fadeGradient_3s_ease-in-out_infinite]">
                  Impermeabilizante do Futuro
                </span>
              </motion.h1>
              
              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="text-3xl lg:text-4xl text-white"
              >
                A solução <span className="text-[#3eada2]">DEFINITIVA</span> para sua obra.
              </motion.h2>
              
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 }}
                className="text-xl lg:text-2xl text-gray-200 max-w-2xl leading-relaxed"
              >
                Com a <span className="text-[#3eada2]">biotecnologia de impermeabilização</span> da EcoConstruction, 
                sua obra se torna mais <span className="text-white">rápida, econômica e sustentável</span>.
              </motion.p>
            </div>

            {/* Glass Effect Cards */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
              className="grid grid-cols-1 sm:grid-cols-2 gap-4"
            >
              {[
                { 
                  icon: Droplet,
                  title: "NBR 12170",
                  description: "Certificação para água potável"
                },
                { 
                  icon: Droplet,
                  title: "100% Atóxico",
                  description: "Zero vapores tóxicos"
                },
                { 
                  icon: Droplet,
                  title: "Aplicação Simples",
                  description: "Sem mão de obra especializada"
                },
                { 
                  icon: Droplet,
                  title: "Durabilidade",
                  description: "Proteção de longa duração"
                }
              ].map((item, index) => {
                const Icon = item.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.9 + index * 0.1 }}
                    whileHover={{ scale: 1.05, y: -5 }}
                    className="flex items-start space-x-3 bg-white/10 backdrop-blur-md rounded-xl p-4 border border-white/20 shadow-xl hover:bg-white/15 transition-all duration-300"
                  >
                    <div className="w-10 h-10 bg-[#3eada2]/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Icon className="h-5 w-5 text-[#3eada2]" />
                    </div>
                    <div>
                      <h3 className="text-white text-sm mb-1">{item.title}</h3>
                      <p className="text-gray-300 text-xs">{item.description}</p>
                    </div>
                  </motion.div>
                );
              })}
            </motion.div>

            {/* CTA Buttons */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.2 }}
              className="pt-4"
            >
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button 
                  size="lg" 
                  onClick={scrollToContact}
                  className="bg-gradient-to-r from-[#3eada2] to-[#2d9186] hover:from-[#2d9186] hover:to-[#3eada2] text-white px-10 py-6 text-lg shadow-2xl group border-2 border-white/20"
                >
                  Solicitar Orçamento Gratuito
                  <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Button>
              </motion.div>
            </motion.div>
          </motion.div>

          {/* Right Content - Glass Effect Stats */}
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="hidden lg:flex flex-col space-y-6"
          >
            {[
              { value: "+25", label: "Anos em", highlight: "Biotecnologia", color: "#3eada2" },
              { value: "100%", label: "Produto", highlight: "Ecológico", color: "#3eada2" },
              { value: "500+", label: "Projetos", highlight: "Entregues", color: "#2d9186" },
              { value: "98%", label: "Taxa de", highlight: "Satisfação", color: "#2d9186" }
            ].map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30, rotate: index % 2 === 0 ? 3 : -3 }}
                animate={{ opacity: 1, y: 0, rotate: 0 }}
                transition={{ delay: 0.6 + index * 0.15 }}
                whileHover={{ 
                  scale: 1.05, 
                  rotate: 0,
                  y: -10,
                  transition: { duration: 0.3 }
                }}
                className="bg-white/10 backdrop-blur-xl p-8 rounded-3xl shadow-2xl border border-white/20 hover:bg-white/15 transition-all duration-300"
              >
                <div className="text-center">
                  <div 
                    className="text-5xl mb-3 drop-shadow-lg"
                    style={{ color: stat.color }}
                  >
                    {stat.value}
                  </div>
                  <div className="text-sm text-gray-200 mb-1">{stat.label}</div>
                  <div className="text-base text-white">{stat.highlight}</div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Mobile Stats */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.3 }}
          className="lg:hidden mt-12"
        >
          <div className="flex space-x-4 overflow-x-auto pb-4 scrollbar-hide">
            {[
              { value: "+25", label: "Anos em Biotecnologia", color: "#3eada2" },
              { value: "100%", label: "Ecológico", color: "#3eada2" },
              { value: "500+", label: "Projetos", color: "#2d9186" },
              { value: "98%", label: "Satisfação", color: "#2d9186" }
            ].map((stat, index) => (
              <div 
                key={index}
                className="bg-white/10 backdrop-blur-xl p-6 rounded-2xl shadow-xl border border-white/20 flex-shrink-0"
              >
                <div className="text-center">
                  <div 
                    className="text-3xl mb-2"
                    style={{ color: stat.color }}
                  >
                    {stat.value}
                  </div>
                  <div className="text-xs text-gray-200 whitespace-nowrap">{stat.label}</div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Scroll Indicator - Primeiro Plano */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ 
          opacity: 1, 
          y: 0,
        }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-30"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="flex flex-col items-center space-y-3 cursor-pointer"
          onClick={() => scrollToSection("produtos")}
        >
          <div className="text-sm text-white/90 backdrop-blur-sm bg-black/20 px-4 py-2 rounded-full">
            Descubra mais
          </div>
          <div className="relative">
            <div className="w-7 h-11 border-2 border-white/70 rounded-full flex justify-center backdrop-blur-sm bg-white/10">
              <motion.div 
                animate={{ y: [0, 12, 0] }}
                transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
                className="w-1.5 h-3 bg-[#3eada2] rounded-full mt-2 shadow-lg shadow-[#3eada2]/50"
              />
            </div>
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
}
