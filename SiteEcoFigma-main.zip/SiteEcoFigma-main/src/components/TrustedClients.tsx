import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { CheckCircle, Award, Users, Building2, ChevronLeft, ChevronRight, Star } from "lucide-react";

export function TrustedClients() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);

  const clientLogos = [
    {
      name: "Petrobras",
      sector: "Petróleo e Energia",
      logo: "https://images.unsplash.com/photo-1689673476137-048bb19d7c20?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXRyb2JyYXMlMjBsb2dvfGVufDF8fHx8MTc2MTIzMTY4Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      projects: "45+ projetos"
    },
    {
      name: "Vale",
      sector: "Mineração",
      logo: "https://images.unsplash.com/photo-1639603683079-7398c604497a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbmclMjBjb21wYW55JTIwbG9nb3xlbnwxfHx8fDE3NjExNzQ4MzF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      projects: "32+ projetos"
    },
    {
      name: "Embraer",
      sector: "Aeronáutica",
      logo: "https://images.unsplash.com/photo-1760138270903-d95903188730?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobm9sb2d5JTIwY29tcGFueSUyMGxvZ298ZW58MXx8fHwxNzYxMTcxODgzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      projects: "28+ projetos"
    },
    {
      name: "Braskem",
      sector: "Petroquímica",
      logo: "https://images.unsplash.com/photo-1701696934149-2878dfe1eb73?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbmVyZ3klMjBjb21wYW55JTIwbG9nb3xlbnwxfHx8fDE3NjEyMzE2ODd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      projects: "38+ projetos"
    },
    {
      name: "Sabesp",
      sector: "Saneamento",
      logo: "https://images.unsplash.com/photo-1620064798309-5a907c1681e0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3Jwb3JhdGUlMjBpbmR1c3RyaWFsJTIwbG9nb3xlbnwxfHx8fDE3NjEyMzE2ODd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      projects: "52+ projetos"
    },
    {
      name: "Porto de Santos",
      sector: "Infraestrutura Portuária",
      logo: "https://images.unsplash.com/photo-1581626216082-f8497d54e0a5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjBjb21wYW55JTIwYnJhbmR8ZW58MXx8fHwxNzYxMjMxNjg4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      projects: "18+ projetos"
    },
    {
      name: "Usiminas",
      sector: "Siderurgia",
      logo: "https://images.unsplash.com/photo-1759390304277-df4f95509186?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwYnVpbGRpbmclMjBsb2dvfGVufDF8fHx8MTc2MTIzMTY4OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      projects: "41+ projetos"
    },
    {
      name: "Suzano",
      sector: "Papel e Celulose",
      logo: "https://images.unsplash.com/photo-1760263137421-7dc09d372e09?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYW51ZmFjdHVyaW5nJTIwY29tcGFueSUyMGJyYW5kfGVufDF8fHx8MTc2MTIzMTY4OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      projects: "35+ projetos"
    },
    {
      name: "Gerdau",
      sector: "Siderurgia",
      logo: "https://images.unsplash.com/photo-1620064798309-5a907c1681e0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3Jwb3JhdGUlMjBpbmR1c3RyaWFsJTIwbG9nb3xlbnwxfHx8fDE3NjEyMzE2ODd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      projects: "29+ projetos"
    },
    {
      name: "Raízen",
      sector: "Bioenergia",
      logo: "https://images.unsplash.com/photo-1701696934149-2878dfe1eb73?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbmVyZ3klMjBjb21wYW55JTIwbG9nb3xlbnwxfHx8fDE3NjEyMzE2ODd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      projects: "26+ projetos"
    },
    {
      name: "JBS",
      sector: "Alimentos",
      logo: "https://images.unsplash.com/photo-1760263137421-7dc09d372e09?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYW51ZmFjdHVyaW5nJTIwY29tcGFueSUyMGJyYW5kfGVufDF8fHx8MTc2MTIzMTY4OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      projects: "44+ projetos"
    },
    {
      name: "Cosan",
      sector: "Energia",
      logo: "https://images.unsplash.com/photo-1689673476137-048bb19d7c20?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXRyb2JyYXMlMjBsb2dvfGVufDF8fHx8MTc2MTIzMTY4Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      projects: "31+ projetos"
    }
  ];

  const testimonials = [
    {
      quote: "A solução EcoConstruction revolucionou nossa operação. Reduzimos custos de manutenção em 70% e eliminamos completamente os problemas de corrosão em nossas estruturas.",
      author: "Carlos Eduardo Silva",
      position: "Gerente de Manutenção Industrial",
      company: "Setor Petroquímico",
      rating: 5
    },
    {
      quote: "Impressionante a durabilidade e facilidade de aplicação. Nossa equipe aplicou sem necessidade de treinamento especializado, economizando tempo e recursos significativos.",
      author: "Ana Maria Santos",
      position: "Engenheira Civil Sênior",
      company: "Saneamento Básico",
      rating: 5
    },
    {
      quote: "Finalmente uma solução que atende às nossas rigorosas normas ambientais sem comprometer a performance. Os resultados superaram todas as expectativas.",
      author: "Roberto Oliveira",
      position: "Diretor de Sustentabilidade",
      company: "Indústria Alimentícia",
      rating: 5
    }
  ];

  const itemsPerPage = 4;
  const totalPages = Math.ceil(clientLogos.length / itemsPerPage);

  // Auto-rotate carousel
  useEffect(() => {
    const interval = setInterval(() => {
      paginate(1);
    }, 10000);

    return () => clearInterval(interval);
  }, [currentIndex]);

  const paginate = (newDirection: number) => {
    setDirection(newDirection);
    setCurrentIndex((prevIndex) => {
      const nextIndex = prevIndex + newDirection;
      if (nextIndex >= totalPages) return 0;
      if (nextIndex < 0) return totalPages - 1;
      return nextIndex;
    });
  };

  const getCurrentClients = () => {
    const start = currentIndex * itemsPerPage;
    const end = start + itemsPerPage;
    return clientLogos.slice(start, end);
  };

  const variants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0
    }),
    center: {
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      x: direction < 0 ? 1000 : -1000,
      opacity: 0
    })
  };

  return (
    <section id="clientes" className="py-24 bg-gradient-to-b from-white via-slate-50 to-blue-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <Badge className="mb-4 bg-blue-100 text-blue-800 hover:bg-blue-100">
            <Award className="h-4 w-4 mr-2" />
            Confiança Comprovada
          </Badge>
          <h2 className="text-3xl lg:text-5xl mb-6 text-gray-900">
            Empresas Líderes Confiam em{" "}
            <span className="bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent">
              Nossa Tecnologia
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Mais de 500 projetos realizados para as principais empresas do Brasil, 
            com 98% de satisfação e zero reclamações
          </p>
        </motion.div>

        {/* Carousel Section */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 border border-gray-100">
            <div className="text-center mb-10">
              <h3 className="text-2xl mb-3 text-gray-900">Nossos Clientes</h3>
              <p className="text-gray-600">Empresas que escolheram a excelência em impermeabilização</p>
            </div>

            {/* Carousel Container */}
            <div className="relative">
              {/* Navigation Buttons */}
              <button
                onClick={() => paginate(-1)}
                className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 z-10 w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-emerald-50 transition-colors group"
                aria-label="Previous clients"
              >
                <ChevronLeft className="w-6 h-6 text-gray-600 group-hover:text-emerald-600" />
              </button>

              <button
                onClick={() => paginate(1)}
                className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 z-10 w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-emerald-50 transition-colors group"
                aria-label="Next clients"
              >
                <ChevronRight className="w-6 h-6 text-gray-600 group-hover:text-emerald-600" />
              </button>

              {/* Logos Grid */}
              <div className="overflow-hidden px-8">
                <AnimatePresence initial={false} custom={direction} mode="wait">
                  <motion.div
                    key={currentIndex}
                    custom={direction}
                    variants={variants}
                    initial="enter"
                    animate="center"
                    exit="exit"
                    transition={{
                      x: { type: "spring", stiffness: 300, damping: 30 },
                      opacity: { duration: 0.2 }
                    }}
                    className="grid grid-cols-2 md:grid-cols-4 gap-8"
                  >
                    {getCurrentClients().map((client, index) => (
                      <motion.div
                        key={`${currentIndex}-${index}`}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: index * 0.1 }}
                        className="group"
                      >
                        <div className="relative bg-gradient-to-br from-gray-50 to-white rounded-2xl p-6 hover:shadow-xl transition-all duration-300 border border-gray-200 hover:border-emerald-300">
                          {/* Logo Container */}
                          <div className="aspect-square flex items-center justify-center mb-4 bg-white rounded-xl p-4 group-hover:scale-105 transition-transform duration-300">
                            <ImageWithFallback
                              src={client.logo}
                              alt={`Logo ${client.name}`}
                              className="w-full h-full object-contain filter grayscale group-hover:grayscale-0 transition-all duration-300"
                            />
                          </div>

                          {/* Client Info */}
                          <div className="text-center">
                            <h4 className="text-gray-900 mb-1">{client.name}</h4>
                            <p className="text-sm text-gray-600 mb-2">{client.sector}</p>
                            <div className="flex items-center justify-center gap-1 text-xs text-emerald-600">
                              <CheckCircle className="w-3 h-3" />
                              <span>{client.projects}</span>
                            </div>
                          </div>

                          {/* Hover Badge */}
                          <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <div className="bg-emerald-500 text-white text-xs px-2 py-1 rounded-full">
                              Cliente Ativo
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </motion.div>
                </AnimatePresence>
              </div>

              {/* Progress Dots */}
              <div className="flex justify-center gap-2 mt-8">
                {Array.from({ length: totalPages }).map((_, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setDirection(index > currentIndex ? 1 : -1);
                      setCurrentIndex(index);
                    }}
                    className={`h-2 rounded-full transition-all duration-300 ${
                      index === currentIndex 
                        ? 'w-8 bg-gradient-to-r from-emerald-500 to-blue-500' 
                        : 'w-2 bg-gray-300 hover:bg-gray-400'
                    }`}
                    aria-label={`Go to page ${index + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Statistics */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="grid md:grid-cols-4 gap-6 mb-16"
        >
          {[
            { value: "500+", label: "Projetos Entregues", color: "from-blue-500 to-blue-600", icon: Building2 },
            { value: "150+", label: "Empresas Atendidas", color: "from-emerald-500 to-emerald-600", icon: Users },
            { value: "98%", label: "Satisfação", color: "from-orange-500 to-orange-600", icon: Star },
            { value: "25+", label: "Anos de Mercado", color: "from-purple-500 to-purple-600", icon: Award }
          ].map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -5 }}
                className="group"
              >
                <div className="relative bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100 overflow-hidden">
                  <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`} />
                  
                  <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-xl flex items-center justify-center mb-4`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  
                  <div className={`text-4xl bg-gradient-to-r ${stat.color} bg-clip-text text-transparent mb-2`}>
                    {stat.value}
                  </div>
                  <div className="text-gray-600">{stat.label}</div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Testimonials */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="grid md:grid-cols-3 gap-8 mb-16"
        >
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -8 }}
              className="group"
            >
              <div className="relative bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 p-8 h-full border border-gray-100">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 to-blue-500 rounded-t-2xl" />
                
                {/* Rating */}
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                  ))}
                </div>
                
                {/* Quote */}
                <blockquote className="text-gray-700 mb-6 leading-relaxed">
                  "{testimonial.quote}"
                </blockquote>
                
                {/* Author */}
                <div className="border-t pt-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <Users className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <div className="text-gray-900">{testimonial.author}</div>
                      <div className="text-sm text-gray-600">{testimonial.position}</div>
                      <div className="text-xs text-blue-600">{testimonial.company}</div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <div className="bg-gradient-to-br from-emerald-50 to-blue-50 border-2 border-emerald-200 rounded-3xl p-12">
            <Building2 className="h-16 w-16 text-emerald-600 mx-auto mb-6" />
            <h3 className="text-3xl mb-4 text-gray-900">
              Junte-se aos Líderes de Mercado
            </h3>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Empresas de diversos setores já descobriram os benefícios da impermeabilização 
              sustentável com produtos EcoConstruction. Seja o próximo case de sucesso.
            </p>
            <div className="flex flex-wrap justify-center gap-3 mb-8">
              {['Sustentável', 'Econômico', 'Durável', 'Atóxico', 'Certificado'].map((tag) => (
                <Badge key={tag} className="bg-white text-gray-700 px-4 py-2 shadow-sm">
                  {tag}
                </Badge>
              ))}
            </div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 bg-gradient-to-r from-emerald-600 to-blue-600 text-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
            >
              Solicitar Orçamento Personalizado
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
