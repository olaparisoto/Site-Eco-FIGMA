import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Send, 
  CheckCircle,
  Building2,
  Users,
  Calculator
} from "lucide-react";

export function Contact() {
  return (
    <section id="contato" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-green-100 text-green-800 hover:bg-green-100">
            <Send className="h-4 w-4 mr-2" />
            Entre em Contato
          </Badge>
          <h2 className="text-3xl lg:text-4xl mb-4 text-gray-900">
            Solicite seu <span className="text-green-600">Orçamento Gratuito</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Nossa equipe técnica está pronta para analisar sua necessidade e fornecer 
            a melhor solução em impermeabilização sustentável para seu projeto.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-12">
          {/* Contact Information */}
          <div className="lg:col-span-1 space-y-8">
            <Card className="bg-gradient-to-br from-green-600 to-green-700 text-white">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Building2 className="h-5 w-5 mr-2" />
                  EcoConstruction
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-start space-x-3">
                  <Phone className="h-5 w-5 text-green-200 mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-medium">Vendas e Suporte</div>
                    <a 
                      href="https://wa.me/5514981377212" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-green-100 hover:text-white transition-colors block"
                    >
                      (14) 98137-7212
                    </a>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <Mail className="h-5 w-5 text-green-200 mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-medium">E-mail Comercial</div>
                    <div className="text-green-100">vendas@ecoconstruction.com.br</div>
                    <div className="text-green-100">suporte@ecoconstruction.com.br</div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <MapPin className="h-5 w-5 text-green-200 mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-medium">Endereço</div>
                    <div className="text-green-100">
                      Rua das Indústrias, 1234<br />
                      Distrito Industrial, São Paulo - SP<br />
                      CEP 01234-567
                    </div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <Clock className="h-5 w-5 text-green-200 mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-medium">Horário de Atendimento</div>
                    <div className="text-green-100">
                      Segunda a Sexta: 8h às 18h<br />
                      Sábado: 8h às 12h
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Why Choose Us */}
            <Card>
              <CardHeader>
                <CardTitle className="text-gray-900 flex items-center">
                  <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
                  Por que nos Escolher?
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-4 w-4 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-medium text-gray-900">Resposta em 24h</div>
                    <div className="text-sm text-gray-600">Orçamentos rápidos e precisos</div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-4 w-4 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-medium text-gray-900">Reunião gratuita</div>
                    <div className="text-sm text-gray-600">Análise profissional do seu projeto</div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-4 w-4 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-medium text-gray-900">Garantia estendida</div>
                    <div className="text-sm text-gray-600">Produtos com garantia diferenciada</div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-4 w-4 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-medium text-gray-900">Suporte técnico</div>
                    <div className="text-sm text-gray-600">Acompanhamento durante aplicação</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl text-gray-900 flex items-center">
                  <Calculator className="h-6 w-6 mr-2 text-green-600" />
                  Solicitar Orçamento
                </CardTitle>
                <p className="text-gray-600">
                  Preencha os dados abaixo e nossa equipe entrará em contato em até 24 horas
                </p>
              </CardHeader>
              <CardContent>
                <form className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">
                        Nome Completo *
                      </label>
                      <Input placeholder="Seu nome completo" />
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">
                        Cargo/Função *
                      </label>
                      <Input placeholder="Ex: Engenheiro Civil, Arquiteto" />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">
                        E-mail Corporativo *
                      </label>
                      <Input type="email" placeholder="seu.email@empresa.com.br" />
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">
                        Telefone/WhatsApp *
                      </label>
                      <Input placeholder="(11) 99999-9999" />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">
                        Empresa *
                      </label>
                      <Input placeholder="Nome da empresa" />
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">
                        Setor de Atuação *
                      </label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione o setor" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="industrial">Industrial</SelectItem>
                          <SelectItem value="construcao">Construção Civil</SelectItem>
                          <SelectItem value="portuario">Portuário</SelectItem>
                          <SelectItem value="saneamento">Saneamento</SelectItem>
                          <SelectItem value="petroquimico">Petroquímico</SelectItem>
                          <SelectItem value="alimenticio">Alimentício</SelectItem>
                          <SelectItem value="outros">Outros</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">
                      Produto de Interesse
                    </label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a linha de produto" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="eco-stone">Eco Stone - Superfícies Minerais</SelectItem>
                        <SelectItem value="eco-wood">Eco Wood - Madeira</SelectItem>
                        <SelectItem value="eco-sea">Eco Sea - Ambientes Marinhos</SelectItem>
                        <SelectItem value="eco-steel">Eco Steel - Superfícies Metálicas</SelectItem>
                        <SelectItem value="todos">Todos os Produtos</SelectItem>
                        <SelectItem value="nao-sei">Não sei qual escolher</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">
                      Área Aproximada (m²)
                    </label>
                    <Input placeholder="Ex: 500 m²" />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">
                      Descrição do Projeto *
                    </label>
                    <Textarea 
                      placeholder="Descreva detalhadamente sua necessidade: tipo de superfície, problemas atuais, condições de aplicação, prazo, etc."
                      rows={4}
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">
                        Prazo Desejado
                      </label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Quando pretende aplicar?" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="urgente">Urgente (até 1 semana)</SelectItem>
                          <SelectItem value="1-mes">Até 1 mês</SelectItem>
                          <SelectItem value="3-meses">Até 3 meses</SelectItem>
                          <SelectItem value="6-meses">Até 6 meses</SelectItem>
                          <SelectItem value="planejamento">Apenas planejamento</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">
                        Reunião
                      </label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Deseja agendar reunião?" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sim">Sim, agendar reunião</SelectItem>
                          <SelectItem value="nao">Não é necessário</SelectItem>
                          <SelectItem value="depois">Decidir depois</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <input type="checkbox" className="mt-1" />
                    <label className="text-sm text-gray-600">
                      Concordo em receber informações técnicas e comerciais da EcoConstruction. 
                      Seus dados estão seguros e não serão compartilhados com terceiros.
                    </label>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-4">
                    <Button size="lg" className="flex-1 bg-green-600 hover:bg-green-700">
                      <Send className="mr-2 h-4 w-4" />
                      Enviar Solicitação
                    </Button>
                    <Button 
                      size="lg" 
                      variant="outline" 
                      className="border-green-600 text-green-600 hover:bg-green-50"
                      onClick={() => window.open('https://wa.me/5514981377212', '_blank')}
                    >
                      <Phone className="mr-2 h-4 w-4" />
                      Ligar Agora
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-green-600 to-blue-600 rounded-2xl p-8 text-white">
            <Users className="h-12 w-12 mx-auto mb-4" />
            <h3 className="text-2xl mb-4">
              Mais de 25 Anos Atendendo Profissionais como Você
            </h3>
            <p className="text-green-100 mb-6 max-w-2xl mx-auto">
              Engenheiros, arquitetos, gestores de manutenção e aplicadores de todo o Brasil 
              confiam na EcoConstruction para resolver seus desafios de impermeabilização.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
              <div className="text-center">
                <div className="text-2xl font-bold">500+</div>
                <div className="text-sm text-green-100">Projetos Entregues</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">98%</div>
                <div className="text-sm text-green-100">Satisfação</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">24h</div>
                <div className="text-sm text-green-100">Resposta Média</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">15+</div>
                <div className="text-sm text-green-100">Anos Mercado</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}