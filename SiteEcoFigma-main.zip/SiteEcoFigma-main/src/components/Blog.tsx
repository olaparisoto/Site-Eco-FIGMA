import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Clock, User, ArrowRight, BookOpen } from "lucide-react";

export function Blog() {
  const blogPosts = [
    {
      id: 1,
      title: "Impermeabilização Sustentável: O Futuro da Construção Civil",
      excerpt: "Descubra como os impermeabilizantes à base de resina vegetal estão revolucionando o mercado e proporcionando benefícios ambientais e econômicos significativos.",
      author: "Eng. Carlos Santos",
      date: "15 de Janeiro, 2024",
      readTime: "8 min",
      category: "Sustentabilidade",
      image: "https://images.unsplash.com/photo-1688981783835-67308623dccb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmVlbiUyMHN1c3RhaW5hYmxlJTIwY29uc3RydWN0aW9uJTIwbWF0ZXJpYWxzfGVufDF8fHx8MTc1ODUzODI0NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      featured: true
    },
    {
      id: 2,
      title: "NBR 12170: Entenda a Importância da Potabilidade em Reservatórios",
      excerpt: "Análise técnica completa sobre os requisitos da norma NBR 12170 e como os produtos EcoConstruction garantem total segurança para água potável.",
      author: "Arq. Maria Silva",
      date: "10 de Janeiro, 2024",
      readTime: "12 min",
      category: "Normas Técnicas",
      image: "https://images.unsplash.com/photo-1648020266285-ffca2a16d7f3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwd2F0ZXJwcm9vZmluZyUyMGNvbnN0cnVjdGlvbnxlbnwxfHx8fDE3NTg1MzgyNDR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      id: 3,
      title: "Redução de Custos: Como Economizar até 60% em Impermeabilização",
      excerpt: "Case study demonstrando economia real em projetos industriais que adotaram soluções EcoConstruction em substituição aos métodos tradicionais.",
      author: "Eng. Roberto Lima",
      date: "5 de Janeiro, 2024",
      readTime: "6 min",
      category: "Economia",
      image: "https://images.unsplash.com/photo-1741446458387-74132b7d49cc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwYnVpbGRpbmclMjByb29mJTIwY29hdGluZ3xlbnwxfHx8fDE3NTg1MzgyNDV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      id: 4,
      title: "Aplicação em Ambientes Marinhos: Desafios e Soluções",
      excerpt: "Conheça as especificidades da linha Eco Sea e como ela resolve definitivamente os problemas de corrosão em estruturas expostas à água salgada.",
      author: "Eng. Naval João Costa",
      date: "28 de Dezembro, 2023",
      readTime: "10 min",
      category: "Aplicações Especiais",
      image: "https://images.unsplash.com/photo-1677093133801-8d977ed5cb43?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJpbmUlMjBib2F0JTIwY29hdGluZyUyMHByb3RlY3Rpb258ZW58MXx8fHwxNzU4NTM4MjQ1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      id: 5,
      title: "Manutenção Preventiva vs. Corretiva: Quando Aplicar Cada Estratégia",
      excerpt: "Guia prático para gestores de manutenção sobre como planejar aplicações preventivas e economizar com retrabalhos.",
      author: "Eng. Ana Rodrigues",
      date: "20 de Dezembro, 2023",
      readTime: "7 min",
      category: "Manutenção",
      image: "https://images.unsplash.com/photo-1648020266285-ffca2a16d7f3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwd2F0ZXJwcm9vZmluZyUyMGNvbnN0cnVjdGlvbnxlbnwxfHx8fDE3NTg1MzgyNDR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      id: 6,
      title: "Resistência Química: Testes Laboratoriais e Resultados Práticos", 
      excerpt: "Relatório técnico detalhado sobre os testes de resistência química realizados conforme normas ASTM e os excelentes resultados obtidos.",
      author: "Dr. Patricia Mendes",
      date: "15 de Dezembro, 2023",
      readTime: "15 min",
      category: "Pesquisa",
      image: "https://images.unsplash.com/photo-1688981783835-67308623dccb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmVlbiUyMHN1c3RhaW5hYmxlJTIwY29uc3RydWN0aW9uJTIwbWF0ZXJpYWxzfGVufDF8fHx8MTc1ODUzODI0NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    }
  ];

  const categories = [
    { name: "Sustentabilidade", count: 8, color: "bg-green-100 text-green-800" },
    { name: "Normas Técnicas", count: 12, color: "bg-blue-100 text-blue-800" },
    { name: "Economia", count: 6, color: "bg-yellow-100 text-yellow-800" },
    { name: "Aplicações Especiais", count: 10, color: "bg-purple-100 text-purple-800" },
    { name: "Manutenção", count: 7, color: "bg-orange-100 text-orange-800" },
    { name: "Pesquisa", count: 5, color: "bg-red-100 text-red-800" }
  ];

  const featuredPost = blogPosts.find(post => post.featured);
  const regularPosts = blogPosts.filter(post => !post.featured);

  return (
    <section id="blog" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-blue-100 text-blue-800 hover:bg-blue-100">
            <BookOpen className="h-4 w-4 mr-2" />
            Blog Técnico
          </Badge>
          <h2 className="text-3xl lg:text-4xl mb-4 text-gray-900">
            Conhecimento <span className="text-blue-600">Especializado</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Artigos técnicos, cases de sucesso e as últimas novidades em impermeabilização sustentável, 
            escritos por nossos especialistas para profissionais como você.
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Featured Article */}
            {featuredPost && (
              <Card className="mb-12 overflow-hidden bg-white shadow-lg">
                <div className="grid md:grid-cols-2">
                  <div className="relative h-64 md:h-auto">
                    <ImageWithFallback
                      src={featuredPost.image}
                      alt={featuredPost.title}
                      className="w-full h-full object-cover"
                    />
                    <Badge className="absolute top-4 left-4 bg-red-600 text-white">
                      Destaque
                    </Badge>
                  </div>
                  <div className="p-8">
                    <Badge className="mb-3 bg-green-100 text-green-800">
                      {featuredPost.category}
                    </Badge>
                    <h3 className="text-2xl mb-4 text-gray-900 leading-tight">
                      {featuredPost.title}
                    </h3>
                    <p className="text-gray-600 mb-6 leading-relaxed">
                      {featuredPost.excerpt}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <div className="flex items-center space-x-1">
                          <User className="h-4 w-4" />
                          <span>{featuredPost.author}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="h-4 w-4" />
                          <span>{featuredPost.readTime}</span>
                        </div>
                      </div>
                      <Button className="bg-blue-600 hover:bg-blue-700">
                        Ler Artigo
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            )}

            {/* Regular Articles Grid */}
            <div className="grid md:grid-cols-2 gap-8">
              {regularPosts.map((post) => (
                <Card key={post.id} className="overflow-hidden bg-white hover:shadow-lg transition-shadow">
                  <div className="relative h-48">
                    <ImageWithFallback
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="secondary" className="bg-gray-100 text-gray-700">
                        {post.category}
                      </Badge>
                      <span className="text-xs text-gray-500">{post.date}</span>
                    </div>
                    <CardTitle className="text-lg text-gray-900 leading-tight line-clamp-2">
                      {post.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                      {post.excerpt}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3 text-xs text-gray-500">
                        <div className="flex items-center space-x-1">
                          <User className="h-3 w-3" />
                          <span>{post.author}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="h-3 w-3" />
                          <span>{post.readTime}</span>
                        </div>
                      </div>
                      <Button size="sm" variant="outline" className="text-blue-600 border-blue-600 hover:bg-blue-50">
                        Ler Mais
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Load More Button */}
            <div className="text-center mt-12">
              <Button size="lg" variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50">
                Carregar Mais Artigos
              </Button>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Categories */}
            <Card className="bg-white">
              <CardHeader>
                <CardTitle className="text-lg text-gray-900">Categorias</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {categories.map((category, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <Badge className={category.color}>
                        {category.name}
                      </Badge>
                      <span className="text-sm text-gray-500">({category.count})</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Newsletter Signup */}
            <Card className="bg-gradient-to-br from-blue-600 to-green-600 text-white">
              <CardHeader>
                <CardTitle className="text-lg text-white">Newsletter Técnica</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-blue-100 text-sm mb-4">
                  Receba mensalmente artigos técnicos, novidades do setor e dicas de aplicação.
                </p>
                <div className="space-y-3">
                  <input
                    type="email"
                    placeholder="Seu e-mail profissional"
                    className="w-full px-3 py-2 text-gray-900 rounded-md text-sm"
                  />
                  <Button className="w-full bg-white text-blue-600 hover:bg-gray-100">
                    Inscrever-se
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Popular Articles */}
            <Card className="bg-white">
              <CardHeader>
                <CardTitle className="text-lg text-gray-900">Mais Lidos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {regularPosts.slice(0, 3).map((post, index) => (
                    <div key={post.id} className="flex space-x-3">
                      <div className="flex-shrink-0">
                        <div className="bg-blue-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold">
                          {index + 1}
                        </div>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-900 line-clamp-2 mb-1">
                          {post.title}
                        </h4>
                        <p className="text-xs text-gray-500">{post.readTime} • {post.category}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}