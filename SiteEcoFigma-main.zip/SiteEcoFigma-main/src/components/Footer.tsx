import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { 
  Phone, 
  Mail, 
  MapPin, 
  Leaf, 
  Facebook, 
  Instagram, 
  Linkedin, 
  Youtube,
  ExternalLink
} from "lucide-react";
import logoImage from "figma:asset/e71f669ef425899a57ca179cfdea3492f3bd94f6.png";

export function Footer() {
  const scrollToContact = () => {
    const element = document.getElementById("contato");
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  const productLinks = [
    { name: "Eco Floor", href: "#eco-floor" },
    { name: "Eco Deck", href: "#eco-deck" },
    { name: "Eco HydroSafe", href: "#eco-hydrosafe" },
    { name: "Eco Station", href: "#eco-station" },
    { name: "Eco Wood", href: "#eco-wood" },
    { name: "Eco Sea", href: "#eco-sea" },
    { name: "Eco Steel", href: "#eco-steel" }
  ];

  const applicationLinks = [
    { name: "Reservatórios de Água", href: "#aplicacoes" },
    { name: "Pisos Industriais", href: "#aplicacoes" },
    { name: "Estruturas Marinhas", href: "#aplicacoes" },
    { name: "Telhados Metálicos", href: "#aplicacoes" },
    { name: "ETEs e ETAs", href: "#aplicacoes" },
    { name: "Madeiras Externas", href: "#aplicacoes" }
  ];

  const resourceLinks = [
    { name: "Blog Técnico", href: "#blog" },
    { name: "Normas e Certificações", href: "#normas" },
    { name: "Cases de Sucesso", href: "#cases" },
    { name: "Documentos Técnicos", href: "#documentos" },
    { name: "Vídeos Aplicação", href: "#videos" },
    { name: "FAQ Técnico", href: "#faq" }
  ];

  const certifications = [
    "NBR 12170:2009",
    "NBR 15487:2007", 
    "NBR 9575:2010",
    "ASTM C-267:2012",
    "ISO 14000"
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="py-16">
          <div className="grid lg:grid-cols-5 gap-8">
            {/* Company Info */}
            <div className="lg:col-span-2">
              <div className="mb-6">
                <img 
                  src={logoImage} 
                  alt="EcoConstruction"
                  className="h-12 w-auto filter brightness-0 invert"
                />
              </div>
              
              <p className="text-gray-300 mb-6 leading-relaxed">
                Há mais de 25 anos oferecendo soluções sustentáveis em impermeabilização 
                com produtos 100% ecológicos feitos a partir de resina vegetal. 
                Protegemos o meio ambiente e garantimos qualidade superior.
              </p>

              <div className="space-y-3 mb-6">
                <div className="flex items-center space-x-3">
                  <Phone className="h-4 w-4 text-green-500 flex-shrink-0" />
                  <div>
                    <a 
                      href="https://wa.me/5514981377212" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-white hover:text-green-400 transition-colors"
                    >
                      (14) 98137-7212
                    </a>
                    <div className="text-gray-400 text-sm">Vendas e Suporte</div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <Mail className="h-4 w-4 text-green-500 flex-shrink-0" />
                  <div>
                    <div className="text-white">vendas@ecoconstruction.com.br</div>
                    <div className="text-gray-400 text-sm">Resposta em até 24h</div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <MapPin className="h-4 w-4 text-green-500 flex-shrink-0" />
                  <div>
                    <div className="text-white">São Paulo, SP</div>
                    <div className="text-gray-400 text-sm">Atendimento Nacional</div>
                  </div>
                </div>
              </div>

              {/* Social Media */}
              <div className="flex space-x-4">
                <Button size="sm" variant="outline" className="border-gray-600 text-gray-400 hover:text-white hover:border-green-500">
                  <Facebook className="h-4 w-4" />
                </Button>
                <Button size="sm" variant="outline" className="border-gray-600 text-gray-400 hover:text-white hover:border-green-500">
                  <Instagram className="h-4 w-4" />
                </Button>
                <Button size="sm" variant="outline" className="border-gray-600 text-gray-400 hover:text-white hover:border-green-500">
                  <Linkedin className="h-4 w-4" />
                </Button>
                <Button size="sm" variant="outline" className="border-gray-600 text-gray-400 hover:text-white hover:border-green-500">
                  <Youtube className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Products */}
            <div>
              <h4 className="text-white mb-6">Produtos</h4>
              <ul className="space-y-3">
                {productLinks.map((link, index) => (
                  <li key={index}>
                    <a 
                      href={link.href} 
                      className="text-gray-400 hover:text-green-500 transition-colors text-sm flex items-center"
                    >
                      {link.name}
                      <ExternalLink className="h-3 w-3 ml-2" />
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Applications */}
            <div>
              <h4 className="text-white mb-6">Aplicações</h4>
              <ul className="space-y-3">
                {applicationLinks.map((link, index) => (
                  <li key={index}>
                    <a 
                      href={link.href} 
                      className="text-gray-400 hover:text-green-500 transition-colors text-sm"
                    >
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Resources */}
            <div>
              <h4 className="text-white mb-6">Recursos</h4>
              <ul className="space-y-3">
                {resourceLinks.map((link, index) => (
                  <li key={index}>
                    <a 
                      href={link.href} 
                      className="text-gray-400 hover:text-green-500 transition-colors text-sm"
                    >
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Certifications Section */}
        <div className="border-t border-gray-800 py-8">
          <div className="text-center mb-6">
            <h4 className="text-white mb-4">Certificações e Normas Atendidas</h4>
            <div className="flex flex-wrap justify-center gap-3">
              {certifications.map((cert, index) => (
                <Badge key={index} variant="outline" className="border-green-500 text-green-500 bg-transparent">
                  {cert}
                </Badge>
              ))}
            </div>
          </div>
          
          <div className="text-center text-sm text-gray-400">
            <p className="mb-2">
              Produtos isentos de solventes (100% sólidos), livres de metais pesados, 
              atóxicos e produzidos com matéria-prima renovável
            </p>
            <p>
              Atende aos requisitos da série de Normas ISO 14000 para produtos sustentáveis
            </p>
          </div>
        </div>

        {/* CTA Section */}
        <div className="border-t border-gray-800 py-8">
          <div className="bg-gradient-to-r from-green-600 to-blue-600 rounded-2xl p-8 text-center">
            <h3 className="text-2xl mb-4 text-white">
              Pronto para Fazer a Mudança?
            </h3>
            <p className="text-green-100 mb-6 max-w-2xl mx-auto">
              Junte-se a centenas de empresas que já descobriram as vantagens 
              da impermeabilização sustentável com produtos EcoConstruction.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-white text-blue-600 hover:bg-gray-100"
                onClick={scrollToContact}
              >
                Solicitar Orçamento Gratuito
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white text-white hover:bg-white hover:text-blue-600"
                onClick={() => window.open('https://wa.me/5514981377212', '_blank')}
              >
                Falar com Representante
              </Button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-sm text-gray-400">
              © 2024 EcoConstruction. Todos os direitos reservados.
            </div>
            
            <div className="flex space-x-6 text-sm text-gray-400">
              <a href="#privacy" className="hover:text-green-500 transition-colors">
                Política de Privacidade
              </a>
              <a href="#terms" className="hover:text-green-500 transition-colors">
                Termos de Uso
              </a>
              <a href="#cookies" className="hover:text-green-500 transition-colors">
                Política de Cookies
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}