import { Button } from "./ui/button";
import { Menu, Phone, ChevronDown } from "lucide-react";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import logoImage from "figma:asset/e71f669ef425899a57ca179cfdea3492f3bd94f6.png";

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
    setIsMenuOpen(false);
  };

  const scrollToContact = () => {
    scrollToSection("contato");
  };

  return (
    <motion.header 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? "bg-white/95 backdrop-blur-lg shadow-lg" 
          : "bg-white/80 backdrop-blur-sm shadow-sm"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <motion.div 
            className="flex items-center"
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.2 }}
          >
            <button 
              onClick={() => scrollToSection("inicio")}
              className="flex-shrink-0 cursor-pointer"
            >
              <img 
                src={logoImage} 
                alt="EcoConstruction"
                className="h-16 w-auto"
              />
            </button>
          </motion.div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            {[
              { label: "Início", id: "inicio" },
              { label: "Produtos", id: "produtos" },
              { label: "Vantagens", id: "vantagens" },
              { label: "Calculadora", id: "calculadora" },
              { label: "Clientes", id: "clientes" },
              { label: "Blog", id: "blog" },
            ].map((item, index) => (
              <motion.button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.1, color: "#3eada2" }}
                whileTap={{ scale: 0.95 }}
                className="text-gray-700 hover:text-[#3eada2] transition-all duration-200 relative group"
              >
                {item.label}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#3eada2] transition-all duration-300 group-hover:w-full" />
              </motion.button>
            ))}
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <a 
                href="https://wa.me/5514981377212"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center text-sm text-gray-600 hover:text-[#3eada2] transition-colors"
              >
                <Phone className="h-4 w-4 mr-2 text-[#3eada2]" />
                <span>(14) 98137-7212</span>
              </a>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                onClick={scrollToContact}
                className="bg-gradient-to-r from-[#3eada2] to-[#2d9186] hover:from-[#2d9186] hover:to-[#3eada2] text-white shadow-lg"
              >
                Solicitar Orçamento
              </Button>
            </motion.div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <Menu className="h-6 w-6" />
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="md:hidden overflow-hidden"
            >
              <div className="px-2 pt-2 pb-3 space-y-1 bg-white/95 backdrop-blur-lg border-t">
                {[
                  { label: "Início", id: "inicio" },
                  { label: "Produtos", id: "produtos" },
                  { label: "Vantagens", id: "vantagens" },
                  { label: "Calculadora", id: "calculadora" },
                  { label: "Clientes", id: "clientes" },
                  { label: "Blog", id: "blog" },
                  { label: "Contato", id: "contato" },
                ].map((item) => (
                  <motion.button
                    key={item.id}
                    onClick={() => scrollToSection(item.id)}
                    whileTap={{ scale: 0.98 }}
                    className="block w-full text-left px-3 py-2 text-gray-700 hover:bg-[#3eada2]/10 hover:text-[#3eada2] rounded-lg transition-colors"
                  >
                    {item.label}
                  </motion.button>
                ))}
                <div className="pt-4 pb-2">
                  <Button 
                    onClick={scrollToContact}
                    className="w-full bg-gradient-to-r from-[#3eada2] to-[#2d9186] hover:from-[#2d9186] hover:to-[#3eada2] text-white"
                  >
                    Solicitar Orçamento
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.header>
  );
}
