
  # EcoConstruction Website and Blog

  This is a code bundle for EcoConstruction Website and Blog. The original project is available at https://www.figma.com/design/NfGstmDmRfvpb6jhdVsKIe/EcoConstruction-Website-and-Blog.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  